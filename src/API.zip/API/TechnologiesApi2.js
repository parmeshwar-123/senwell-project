import { SiAdobephotoshop } from "react-icons/si";
import { SiAdobeillustrator } from "react-icons/si";
import { SiAdobeaftereffects } from "react-icons/si";
import { ReactBanner } from "../../../images/images";

   const Technologies = [
    {
        id:1,
        Technologies:'front-end',
        breadcrums:'Front-end Developers',
        ButtonText:'Contact Us',
        HeroBanner:[{  HeroParagraph:'Build up the digital image of your business with the engaging design and functional perfection of our front-end solutions.',
    
    }],
        RichInterfacesTitle:'Rich Interfaces.Happy Users.',
        RichInterfacesPara:'Do you want your app or website to be engaging and effective in delivering on your business goals? Hire a front-end development company that leverages 20 years of experience, in-depth tech and design expertise, and a solid portfolio of success stories. With a guarantee that your project will be completed within the estimated time and budget, we create appealing user interfaces that represent your business, products, and services in the best light. Let’s make your software shine and create positive, memorable experiences for your customers!',
        RichInterfacesList:[
            {
 
                Numbers:'800+',
                PerformanceListTitle:'Completed Projects',
                PerformanceListPara :'Whether you hire one or 10 React developers, we guarantee that you will be working only with Middle and Senior level engineers'
            },
            {
             Numbers:'280+',
             PerformanceListTitle:'Dedicated Developers',
             PerformanceListPara :'Customer-obsessed professionals with broad software development experience, niche tech skills and deep industry-specific expertise.'
         },
         {
             Numbers:'20',
             PerformanceListTitle:'Years of Experience',
             PerformanceListPara :'Over the years of reliable full-cycle software development service to our clients, we’ve honed our skills and matured our processes.'
         }
        ],
        TechnologiesExpertiesFrontEndTitle:'Tech Stack',
        TechnologiesExpertiesFrontEndPara:'Our front-end development services include a wide range of proven technologies, programming languages, and tools that enable us to take on front-end development projects of any complexity and scale. We’re flexible with broad domain expertise to help you pick the tech stack that suits your business needs perfectly.',
        TechnologiesExpertiesFrontEndList:[
            {
                icon:<SiAdobephotoshop/>,
                title:'JavaScript',
            },
            {
             icon:<SiAdobephotoshop/>,
             title:'Angular',
         },
         {
             icon:<SiAdobephotoshop/>,
             title:'React',
         },
         {
             icon:<SiAdobephotoshop/>,
             title:'TypeScript',
         },
         {
            icon:<SiAdobeillustrator/>,
            title:'Vue.Js',
        },
        ],
        FrontDevelopmentStepstitle:'Front-end development step by step' ,
        FrontDevelopmentStep:[
            {
                icon:'',
                title:'Write to Us',
                description:'Tell us about your front-end development needs and we will take care of the rest.'
            },
            {
             icon:'',
             title:'Define requirements',
             description:'We will talk through all the necessary details, identify all tech specs and requests.'
         },
            {
             icon:'',
             title:'Meet your team',
             description:'We will handpick a development team that fits your needs best and start on your project at once.'
            },
       
         {
             icon:'',
             title:'Prepare to deploy',
             description:'Your project will be delivered on time and within budget. Implement and prosper!'
         },
        ],
        frontenddevelopmentpara:'Hire an experienced front-end development company and tailor a distinctive digital image for your business.',
        frontenddevelopmentButtonText:'Get in Touch',
        BenefitsFrontEndTitle:'Benefits of Front-EndDevelopment with QArea',
        BenefitsFrontEndSenwell:[
            {
                Number:'01',
                title:'Internal Educational Program',
                description:'Our front-end developers are always top of the class thanks to our internal educational courses. Their expertise goes far beyond following the latest tech trends.'
            },
            {
             Number:'02',
             title:'Instant Resource Replacement',
             description:'We handpick the best developers for your project, but with a roster of 280+ engineers, we’re always ready to change your development lineup.'
         },
         {
             Number:'03',
             title:'Transparent Code Monitoring',
             description:'We have a quick, smooth, and transparent quality assurance system. Rest assured, not a single line of code will go unchecked.'
         },
         {
             Number:'04',
             title:'Tailoring Processes if Needed',
             description:'Every project and business requires a unique approach. We default to Agile but have extensive experience in working with Waterfall, V-Model, Spiral, etc.'
         },
         {
             Number:'05',
             title:'System Administration Included',
             description:'We provide system administration services at no extra cost to you. You can be sure that your business systems run efficiently and IT management costs are optimized.'
         },
         {
             Number:'06',
             title:'Trial Periods for New Employees',
             description:'When new developers join your team, you can run a short pilot project with the candidates to be confident in their ability to meet your expectations and the project’s technical requirements.'
         },    
        ],
        SuccessStoriesTitle:'Start your front-end development with confidence!',
        SuccessStoriesPara:'Leverage the broad technical skills and cross-domain expertise of a front-end development company proven by 20 years of reliable service and 800+ success stories.',
        SuccessStoriesButtonText:'Let`S Talk',
        SuccessStoriesImg:' ',
        FullCycleSoftwareImg:'',
        FullCycleSoftwareTitle:'Full-cycle software development teams',
        FullCycleSoftwareDetails:'Project Manager',
        FullCycleSoftwareProjectManager:[
            {
                Text:'If you’d rather focus on the big picture, hire an experienced project manager to take care of your software development. QArea’s processes are appraised at CMMI-DEV Level 3. We excel at everything from planning and scheduling to progress tracking and workflow optimization.',
            }
        ],
        FullCycleSoftwareDetails:'Business Analyst',
        FullCycleSoftwareDetailsBusinesAnalyst:[
            {
                Text:'We have the right people to help point your project into the most profitable, future-proof direction. Through rigorous research and detailed documentation, our experienced business analysts will help you refine the project requirements and improve business processes.',
            }
        ],
        FullCycleSoftwareDetails:'UI/UX Designers',
        FullCycleSoftwareDetailsUIUXDesigners:[
            {
                Text:'In addition to equipping your software solution with a powerful backend, you need to make your frontend visually attractive, interactions intuitive, and user journeys as enjoyable as ever. If you need help designing an appealing UI and captivating UX, we have the right people for the job.',
            }
        ],
        FullCycleSoftwareDetails:'Developers',
        FullCycleSoftwareDetailsDevelopers:[
            {
                Text:'The engineers who turn thousands of lines of good code into great software, websites, and applications used by millions of people around the world.',
            }
        ],
        FullCycleSoftwareDetails:'DevOps Engineers',
        FullCycleSoftwareDetailsDevOpsEngineers:[
            {
                Text:'The ability to reduce the time needed to integrate changes while improving the quality is a great competitive edge to have in today’s software market. We employ best CI/CD practices to minimize the number of errors during integration and deployment to streamline your project.',
            }
        ],
        FullCycleSoftwareDetails:'Testing and QA Teams',
        FullCycleSoftwareDetailsTestingandQATeams:[
            {
                Text:'From meticulous manual testing to writing complex automated testing solutions, our bright QA engineers and scrupulous testing teams will make certain your software solution is free from any performance, stability, or functionality issues.',
            }
        ],
        FullCycleSoftwareButtonText:'Requists Specialists',
        ChooseUsTitel:'Why Choose Us',
        ChooseUs:[
            {
                icons:'',
                titel:'Start fast. Finish with confidence.',
                para:'Our goal is to help you launch quickly and make sure you’ll want to work with us again.',
            },
            {
                icons:'',
                titel:'100% Transparency',
                para:'Clear communication, flexible pricing, and full dedication to your success.',
            },
            {
                icons:'',
                titel:'Excellent Code Quality',
                para:'We check the quality of our code at every step of development to ensure best results.',
            },
            {
                icons:'',
                titel:'Cross-domain expertise',
                para:'Need services beyond front-end development? We will have you covered.',
            },
        ],
        FormDetailTitel:'Write to us.',
        FormDetailSubTitel:'Tell us about your project.',

       },


        {
            id:2,
            Technologies:'front-end',
            name:'react',
            breadcrums:'React Development Services',
            HeroBanner:[{
                name:'react',
                HeroParagraph:'Equip your website or web application with a responsive and intuitive user interface built by React outsourcing professionals.',
                image:ReactBanner
            }],
            HeroParagraph:'Equip your website or web application with a responsive and intuitive user interface built by React outsourcing professionals.',
            PerformanceTitle:'Flawless Performance.Great User Experience',
            PerformancePara:'React is a JavaScript library with a component-based approach and well-defined lifecycle for building user interfaces. It’s utilized to create dynamic web applications and high-end mobile solutions. React features great performance, stability of code, and interoperability with other systems. Today React is a widely used technology adopted by giants like Facebook, Netflix, and Dropbox. Enjoy using their products? Utilize our React outsourcing capacity and build a robust solution for your own business!',
            PerformanceList:[
                {
        
                    Numbers:'30+',
                    PerformanceListTitle:'Skilled Engineers',
                    PerformanceListPara :'Whether you hire one or 10 React developers, we guarantee that you will be working only with Middle and Senior level engineers'
                },
                {
                    Numbers:'35+',
                    PerformanceListTitle:'React Projects',
                    PerformanceListPara :'With years of experience delivering top-notch React development services, our skilled developers can handle projects of any complexity.'
                },
                {
                    Numbers:'8+',
                    PerformanceListTitle:'Years of Experience',
                    PerformanceListPara :'Our most experienced React engineers were early adopters of the library and started implementing its features as early as 2013.'
                }
            ],
            TechnologiesExpertiesTitle:'Tech Stack',
            TechnologiesExpertiesPara:'Our expertise does not end with Angular development outsourcing. Our skills and experience cover almost every programming language, framework, and library, both proven by years and recently introduced by industry leaders like Google or Microsoft.',
            TechnologiesExperties:[
                {
                    icon:<SiAdobephotoshop/>,
                    title:'JavaScript',
                },
                {
                    icon:<SiAdobephotoshop/>,
                    title:'Angular',
                },
                {
                    icon:<SiAdobephotoshop/>,
                    title:'React',
                },
                {
                    icon:<SiAdobephotoshop/>,
                    title:'TypeScript',
                },
                {
                    icon:<SiAdobephotoshop/>,
                    title:'Vue.Js',
                },
            ],
            ReactDevelopmentSteptitle:'React development step by step' ,
            ReactDevelopmentStep:[
                {
                    icon:'',
                    title:'Write to Us',
                    description:'Tell us about your front-end development needs and we will take care of the rest.'
                },
                {
                icon:'',
                title:'Define requirements',
                description:'We will talk through all the necessary details, identify all tech specs and requests.'
            },
                {
                icon:'',
                title:'Meet your team',
                description:'We will handpick a development team that fits your needs best and start on your project at once.'
                },
        
            {
                icon:'',
                title:'Prepare to deploy',
                description:'Your project will be delivered on time and within budget. Implement and prosper!'
            },
            ],
            ReactExpertiespara:'Run a pilot project to ensure React outsourcing expertise is exactly what your business needs.',
            ReactExpertiesButtonText:'Get in Touch',
            DevelopmentStepstitle:'React development step by step' ,
            DevelopmentWithSenwell:[
                {
                    Number:'01',
                    title:'Internal Educational Progra',
                    description:'Our front-end developers are always top of the class thanks to our internal educational courses. Their expertise goes far beyond following the latest tech trends.'
                },
                {
                    Number:'02',
                    title:'Instant Resource Replacement',
                    description:'We handpick the best developers for your project, but with a roster of 280+ engineers, we’re always ready to change your development lineup.'
                },
                {
                    Number:'03',
                    title:'Transparent Code Monitoring',
                    description:'We have a quick, smooth, and transparent quality assurance system. Rest assured, not a single line of code will go unchecked.'
                },
                {
                    Number:'04',
                    title:'Tailoring Processes if Needed',
                    description:'Every project and business requires a unique approach. We default to Agile but have extensive experience in working with Waterfall, V-Model, Spiral, etc.'
                },
                {
                    Number:'05',
                    title:'System Administration Included',
                    description:'We provide system administration services at no extra cost to you. You can be sure that your business systems run efficiently and IT management costs are optimized.'
                },
                {
                    Number:'06',
                    title:'Trial Periods for New Employees',
                    description:'When new developers join your team, you can run a short pilot project with the candidates to be confident in their ability to meet your expectations and the project’s technical requirements.'
                },    
            ],
            ReactOutsourcingTitle:'Looking for a reliable React outsourcing partner?',
            ReactOutsourcingPara:'We’re ready to put our best foot forward! Whether you’re looking for a single developer or an entire full-cycle team, QArea is where you get your project delivered on time and within budget.',
            ReactOutsourcingButtonText:'Get a Quote',
            SuccessStoriesImg:' ',
            FullCycleSoftwareImg:'',
            FullCycleSoftwareTitle:'Full-cycle software development teams',
            FullCycleSoftwareDetails:'Project Manager',
            FullCycleSoftwareProjectManager:[
                {
                    Text:'If you’d rather focus on the big picture, hire an experienced project manager to take care of your software development. QArea’s processes are appraised at CMMI-DEV Level 3. We excel at everything from planning and scheduling to progress tracking and workflow optimization.',
                }
            ],
            FullCycleSoftwareDetails:'Business Analyst',
            FullCycleSoftwareDetailsBusinesAnalyst:[
                {
                    Text:'We have the right people to help point your project into the most profitable, future-proof direction. Through rigorous research and detailed documentation, our experienced business analysts will help you refine the project requirements and improve business processes.',
                }
            ],
            FullCycleSoftwareDetails:'UI/UX Designers',
            FullCycleSoftwareDetailsUIUXDesigners:[
                {
                    Text:'In addition to equipping your software solution with a powerful backend, you need to make your frontend visually attractive, interactions intuitive, and user journeys as enjoyable as ever. If you need help designing an appealing UI and captivating UX, we have the right people for the job.',
                }
            ],
            FullCycleSoftwareDetails:'Developers',
            FullCycleSoftwareDetailsDevelopers:[
                {
                    Text:'The engineers who turn thousands of lines of good code into great software, websites, and applications used by millions of people around the world.',
                }
            ],
            FullCycleSoftwareDetails:'DevOps Engineers',
            FullCycleSoftwareDetailsDevOpsEngineers:[
                {
                    Text:'The ability to reduce the time needed to integrate changes while improving the quality is a great competitive edge to have in today’s software market. We employ best CI/CD practices to minimize the number of errors during integration and deployment to streamline your project.',
                }
            ],
            FullCycleSoftwareDetails:'Testing and QA Teams',
            FullCycleSoftwareDetailsTestingandQATeams:[
                {
                    Text:'From meticulous manual testing to writing complex automated testing solutions, our bright QA engineers and scrupulous testing teams will make certain your software solution is free from any performance, stability, or functionality issues.',
                }
            ],
            FullCycleSoftwareButtonText:'Requists Specialists',
            ChooseUsTitel:'Why Choose Us',
            ChooseUs:[
                {
                    icons:'',
                    titel:'Start fast. Finish with confidence.',
                    para:'Our goal is to help you launch quickly and make sure you’ll want to work with us again.',
                },
                {
                    icons:'',
                    titel:'100% Transparency',
                    para:'Clear communication, flexible pricing, and full dedication to your success.',
                },
                {
                    icons:'',
                    titel:'Excellent Code Quality',
                    para:'We check the quality of our code at every step of development to ensure best results.',
                },
                {
                    icons:'',
                    titel:'Cross-domain expertise',
                    para:'Need services beyond front-end development? We will have you covered.',
                },
            ],
            FormDetailTitel:'Write to us.',
            FormDetailSubTitel:'Tell us about your project.',
            },
       {
        id:3,
        Technologies:'front-end',
        name:'angular',
        breadcrums:'Angular Development Services',
        HeroParagraph:'We know how to build lean and fast-responding user interfaces for websites and applications with the Angular web framework by Google.',
        PerformanceTitle:'Proven development tools. Flawless and products.',
        PerformancePara:'Angular is an open-source web application framework developed by Google. Based on TypeScript, the framework is characterized by a large number of components and templates that can be utilized for efficient UI development. With our mature project management approaches and years of expertise in the field, QArea’s Angular development outsourcing services will ensure a fast and error-free development process on your project.',
        PerformanceList:[
            {
                Numbers:'17+',
                PerformanceListTitle:'Engineers',
                PerformanceListPara :'Our company employs some of the most experienced and skilled Angular developers in Eastern Europe.'
            },
            {
             Numbers:'33+',
             PerformanceListTitle:' Projects',
             PerformanceListPara :'Angular development outsourcing has filled our portfolio with lots of projects worthy of your attention.'
         },
         {
             Numbers:'15+',
             PerformanceListTitle:'Years of Experience',
             PerformanceListPara :'Being in the game that long, we didn’t lose our passion for innovative tools such as Angular framework.'
         }
        ],
        TechnologiesExpertiesTitle:'Tech Stack',
        TechnologiesExpertiesPara:'Our expertise does not end with Angular development outsourcing. Our skills and experience cover almost every programming language, framework, and library, both proven by years and recently introduced by industry leaders like Google or Microsoft.',

        TechnologiesExperties:[
            {
                icon:<SiAdobeaftereffects/>,
                title:'Ios',
            },
            {
             icon:<SiAdobephotoshop/>,
             title:'Andried',
         },
         {
             icon:<SiAdobephotoshop/>,
             title:'React-Native',
         },
         {
             icon:<SiAdobephotoshop/>,
             title:'Obj-C',
         },
         {
            icon:<SiAdobeaftereffects/>,
            title:'Swift',
        },
        {
         icon:<SiAdobephotoshop/>,
         title:'Ionic',
     },
     {
         icon:<SiAdobephotoshop/>,
         title:'Cordova',
     },
     {
         icon:<SiAdobephotoshop/>,
         title:'Kotlin',
     },
        ],
        DevelopmentSteptitle:'How to Get Started' ,
           DevelopmentStep:[
            {
                icon:'',
                title:'One click away',
                description:'Just fill in the intake form here on this website, and we’ll start estimating your project right away.'
            },
            {
             icon:'',
             title:'Goals setting',
             description:'Together with our manager, you will define your project objectives for the long term.'
         },
            {
             icon:'',
             title:'Dedicated team',
             description:'We’ll form the team to work on your project and even hire AngularJS developers if needed',
            },
       
         {
             icon:'',
             title:'Let’s go!',
             description:'The work will start immediately after you meet and approve your software development team.'
         },
        ],
         AngularDevelopmentpara:'No matter what kind of solution you’re going for, it sure needs a high-quality UI. Let our Angular development team help you build one!',
        DevelopmentWithSenwell:[
            {
                Number:'01',
                title:'Quality first',
                description:'We put code quality first and never compromise it because of deadlines or budgets. Working with QArea, you’ll get the most out of your project plan no matter what.'
            },
            {
             Number:'02',
             title:'Turnkey products',
             description:'We develop software solutions from scratch, meaning you don’t have to worry about project planning, business analysis, UI/UX design, technical support, etc.'
         },
         {
             Number:'03',
             title:'Fair & Transparent',
             description:'We support bureaucracy-free communication with all our clients and arrange the working process in a way that allows them to access the results of our ongoing work easily and quickly.'
         },
         {
             Number:'04',
             title:'Global reputation',
             description:'For the last 15 years, we have been working on our name to become a globally-known brand. Our industry awards and projects with Fortune 500 companies prove it wasn’t for nothing.',
         },
         {
             Number:'05',
             title:'Software teams A to Z',
             description:'Unlike freelance, our Angular development outsourcing services provide dedicated teams that can cover all the software development stages. You won’t be bothered with looking for a designer or QA analyst, that’s our job.',
         },
         {
             Number:'06',
             title:'Post-production support',
             description:'Even it seems like the end of your journey, the development stage is far from the finish line. In fact, post-production support can be stressful and quite expensive; good news we’re providing it to all our projects.',
         },
        ],
        EstimateStoriesTitle:'Follow best Angular development standards',
        EstimateStoriesPara:'The client-facing side of an app determines its success. After all, if it doesn’t look and work well, who’s going to use it? Our Angular development services pair developers with designers to create the most inviting, intuitive, and memorable user interfaces for your users to enjoy.',
        EstimateiesButtonText:'Estimate a Project',
        SuccessStoriesImg:' ',
        FullCycleSoftwareImg:'',
        FullCycleSoftwareTitle:'Full-cycle software development teams',
        FullCycleSoftwareDetails:'Project Manager',
        FullCycleSoftwareProjectManager:[
            {
                Text:'If you’d rather focus on the big picture, hire an experienced project manager to take care of your software development. QArea’s processes are appraised at CMMI-DEV Level 3. We excel at everything from planning and scheduling to progress tracking and workflow optimization.',
            }
        ],
        FullCycleSoftwareDetails:'Business Analyst',
        FullCycleSoftwareDetailsBusinesAnalyst:[
            {
                Text:'We have the right people to help point your project into the most profitable, future-proof direction. Through rigorous research and detailed documentation, our experienced business analysts will help you refine the project requirements and improve business processes.',
            }
        ],
        FullCycleSoftwareDetails:'UI/UX Designers',
        FullCycleSoftwareDetailsUIUXDesigners:[
            {
                Text:'In addition to equipping your software solution with a powerful backend, you need to make your frontend visually attractive, interactions intuitive, and user journeys as enjoyable as ever. If you need help designing an appealing UI and captivating UX, we have the right people for the job.',
            }
        ],
        FullCycleSoftwareDetails:'Developers',
        FullCycleSoftwareDetailsDevelopers:[
            {
                Text:'The engineers who turn thousands of lines of good code into great software, websites, and applications used by millions of people around the world.',
            }
        ],
        FullCycleSoftwareDetails:'DevOps Engineers',
        FullCycleSoftwareDetailsDevOpsEngineers:[
            {
                Text:'The ability to reduce the time needed to integrate changes while improving the quality is a great competitive edge to have in today’s software market. We employ best CI/CD practices to minimize the number of errors during integration and deployment to streamline your project.',
            }
        ],
        FullCycleSoftwareDetails:'Testing and QA Teams',
        FullCycleSoftwareDetailsTestingandQATeams:[
            {
                Text:'From meticulous manual testing to writing complex automated testing solutions, our bright QA engineers and scrupulous testing teams will make certain your software solution is free from any performance, stability, or functionality issues.',
            }
        ],
        FullCycleSoftwareButtonText:'Requists Specialists',
        ChooseUsTitel:'Why Choose Us',
        ChooseUs:[
            {
                icons:'',
                titel:'Start with confidence.',
                para:'We provide our clients with a free consultation to gather the necessary information on your future project and estimateit correctly.',
            },
            {
                icons:'',
                titel:'Full-cycle service',
                para:'On top of software development teams, we also handle all the organizational tasks like workspace rentals and system administration.',
            },
            {
                icons:'',
                titel:'Cross-domain expertise',
                para:'Senwell portfolio holds various projects belonging to the most diverse industries, from healthcare to automotive, finance, and eCommerce.',
            },
            {
                icons:'',
                titel:'Straight to the point',
                para:'We keep the development process simple and straightforward. No blown-up budgets or unnecessary roles on a team.',
            },
        ],
        FormDetailTitel:'Get a quote today!',
        FormDetailSubTitel:'Enter your project details.',
    },
    {
        id:4,
        Technologies:'back-end',
        breadcrums:'Back-End Software Development Services',
        HeroParagraph:'Hire backend developers to complete your software with seamless performance, efficient data processing, and impenetrable security.',
        EfficientProcessesTitle:'Efficient Processes.Outstanding Results.',
        EfficientProcessesPara:'Over years of delivering complex custom back-end solutions, we’ve built strong expertise in reliable architecture, efficient development practices, and transparent communication with clients. Our backend engineers have a proven track record of creating complex databases, scalable back-end systems, and other back-end solutions for websites, mobile applications, and software suites.',
        EfficientProcessesList:[
            {
                Numbers:'20',
                Title:'Years of back-end development',
                description:'Extensive experience in building powerful and secure back-end solutions for various domains and applications.'
            },
            {
             Numbers:'250+',
             Title:' Accomplished professionals',
             description :'Our experienced backend engineers are skilled in a wide range of technologies and domains.'
         },
         {
             Numbers:'800+',
             Title:'Success stories',
             description:'With hundreds of projects completed, our qualified engineers are ready for jobs of any complexity and scale.'
         }   
        ],
        OurTechnologiesExpertiesTitle:'Our Technology Expertise',
        OurTechnologiesExpertiesPara:'Senwell Solutions has the right talent to help you build robust back-end solutions. Whether you need a simple web API or a complex custom-made CRM system, hire backend engineers proficient in a wide range of cutting-edge technologies, programming languages, and tools.',
        OurTechnologiesExpertiesList:[
            {
                icon:<SiAdobeaftereffects/>,
                title:'Java',
            },
            {
             icon:<SiAdobephotoshop/>,
             title:'PHP',
         },
         {
             icon:<SiAdobephotoshop/>,
             title:'Golang',
         },
         {
             icon:<SiAdobephotoshop/>,
             title:'Node.Js',
         },
         {
            icon:<SiAdobeaftereffects/>,
            title:'Python',
        },
        {
         icon:<SiAdobephotoshop/>,
         title:'C#',
     },
     {
         icon:<SiAdobephotoshop/>,
         title:'.NET',
     },
     {
         icon:<SiAdobephotoshop/>,
         title:'c/c++',
     },
     {
        icon:<SiAdobephotoshop/>,
        title:'Electron',
    },
    {
        icon:<SiAdobephotoshop/>,
        title:'PostgreSQL',
    },
    {
        icon:<SiAdobephotoshop/>,
        title:'Flask',
    },
    {
        icon:<SiAdobephotoshop/>,
        title:'Django',
    },
    {
        icon:<SiAdobephotoshop/>,
        title:'Mongo',
    },
     ],
     DevelopmentGetStartedtitle:'How to Get Started' ,
     DevelopmentGetStarted:[
               {
                   icon:'',
                   title:'Reach out to us',
                   description:'Fill our contact form, tell us about your project, and we’ll be in touch within one business day.'
               },
               {
                icon:'',
                title:'Outline your goals',
                description:'Your personal manager will provide a quote based on your project requirements.'
            },
               {
                icon:'',
                title:'Meet your team',
                description:'We will handpick the best suitable candidates for your Node.js development project.',
               },
          
            {
                icon:'',
                title:'Get to work',
                description:'Now that your team is formed, let’s turn your ideas into a successful Node.js solution!'
            },
           ],
        DevelopmentservicesPara:'Need help building a powerful engine to run your software solution? Hire backend developers from Senwell!',
        DevelopmentservicesButtonText:'Get in Touch',
        BenefitsBackEndjsTitle:'Benefits of Back-End Development with Senwell Solutions',
        BenefitsBackEndList:[
           {
            Number:'01',
            title:'Trial Periods for New Employees',
            description:'We provide our clients with the opportunity to have a test run with the candidates before they finalize their choice. We want you to be confident we’ll get the job done on time and within budget.',
           },
           {
            Number:'02',
            title:'Transparent Code Monitoring',
            description:'When hiring from QArea, you get access to our proprietary tools that provide useful code quality metrics to help your project standardize the quality of code and maintain it on a high level.',
           },
           {
            Number:'03',
            title:'Equipment Rental Included',
            description:'You don’t pay any extra for our specialists’ workstations and the equipment they use. In addition, you get access to over 250 physical devices from smartphones to tablets to test your app.',
           },
           {
            Number:'04',
            title:'Flexible Workflows & Processes',
            description:'Our highly experienced specialists can not only get in sync with your team quickly and without effort, but help optimize the development processes to achieve maximum efficiency on the project.',
           },
           {
            Number:'05',
            title:'System Administration Included',
            description:'Don’t think about anything but your project’s success as we take care of all the administrative and IT support—help you set up efficient communication, integrate project management tools, etc.',
           },
           {
            Number:'06',
            title:'Fast Resource Replacement',
            description:'We are very scrupulous when it comes to picking the best candidates for our clients’ requirements. In case a discrepancy does happen, however, we provide a fitting replacement without delay.',
           },
        ],
        BackendTitle:'We’ve got your back',
        BackendPara:'Hire our experienced backend developers and we’ll make sure your applications, databases, and servers work seamlessly with each other.',
        BackendButtonText:'Get in Touch',
        SuccessStoriesImg:' ',
        FullCycleSoftwareImg:'',
        FullCycleSoftwareTitle:'Full-cycle software development teams',
        FullCycleSoftwareDetails:'Project Manager',
        FullCycleSoftwareProjectManager:[
            {
                Text:'If you’d rather focus on the big picture, hire an experienced project manager to take care of your software development. QArea’s processes are appraised at CMMI-DEV Level 3. We excel at everything from planning and scheduling to progress tracking and workflow optimization.',
            }
        ],
        FullCycleSoftwareDetails:'Business Analyst',
        FullCycleSoftwareDetailsBusinesAnalyst:[
            {
                Text:'We have the right people to help point your project into the most profitable, future-proof direction. Through rigorous research and detailed documentation, our experienced business analysts will help you refine the project requirements and improve business processes.',
            }
        ],
        FullCycleSoftwareDetails:'UI/UX Designers',
        FullCycleSoftwareDetailsUIUXDesigners:[
            {
                Text:'In addition to equipping your software solution with a powerful backend, you need to make your frontend visually attractive, interactions intuitive, and user journeys as enjoyable as ever. If you need help designing an appealing UI and captivating UX, we have the right people for the job.',
            }
        ],
        FullCycleSoftwareDetails:'Developers',
        FullCycleSoftwareDetailsDevelopers:[
            {
                Text:'The engineers who turn thousands of lines of good code into great software, websites, and applications used by millions of people around the world.',
            }
        ],
        FullCycleSoftwareDetails:'DevOps Engineers',
        FullCycleSoftwareDetailsDevOpsEngineers:[
            {
                Text:'The ability to reduce the time needed to integrate changes while improving the quality is a great competitive edge to have in today’s software market. We employ best CI/CD practices to minimize the number of errors during integration and deployment to streamline your project.',
            }
        ],
        FullCycleSoftwareDetails:'Testing and QA Teams',
        FullCycleSoftwareDetailsTestingandQATeams:[
            {
                Text:'From meticulous manual testing to writing complex automated testing solutions, our bright QA engineers and scrupulous testing teams will make certain your software solution is free from any performance, stability, or functionality issues.',
            }
        ],
        FullCycleSoftwareButtonText:'Requists Specialists',
        ChooseUsTitel:'Why Choose Us',
        ChooseUs:[
            {
                icons:'',
                titel:'Start fast. Finish with confidence.',
                para:'Our goal is to help you launch quickly and make sure you’ll want to work with us again.',
            },
            {
                icons:'',
                titel:'100% Transparency',
                para:'Clear communication, flexible pricing, and full dedication to your success.',
            },
            {
                icons:'',
                titel:'Excellent Code Quality',
                para:'We check the quality of our code at every step of development to ensure best results.',
            },
            {
                icons:'',
                titel:'Cross-domain expertise',
                para:'Need services beyond Back-End Development? We will have you covered.',
            },
        ],
        FormDetailTitel:'Get a quote today!',
        FormDetailSubTitel:'Enter your project details.',
      },
    {
        id:5,
        Technologies:'back-end',
        name:'nodejs',
        breadcrums:'Node js Development Services',
        HeroParagraph:'From custom real-time web apps and chat programs to scalable network systems, collaboration tools, and APIs — our Node.js development team can build it for you.',
        EasyScalabilityTitle:'Easy Scalability. Faster Time-to-market.',
        EasyScalabilityPara:'Node.js is an open-source runtime environment that lets developers effectively use JavaScript as a single technology for web application development. This makes scalability a core part of the technology and significantly boosts development speed. From lightning-fast MVP development to building complex yet scalable web platforms, there are numerous opportunities Node.js development outsourcing opens for both startups and well-established businesses.',
        EasyScalabilityList:[
            {
                Numbers:'20',
                Title:'Skilled Developers',
                description:'Whether you hire one or more Node.js developers, we guarantee that you will be working with Middle and Senior level experts only.'
            },
            {
             Numbers:'10',
             Title:' Node.js Projects',
             description :'Angular development outsourcing has filled our portfolio with lots of projects worthy of your attention.'
         },
         {
             Numbers:'8',
             Title:'Years of Experience',
             description:'Our Agile approach, years of experience, and mature processes allow us to handle Node.js projects of any complexity and scale.'
         }   
        ],
        OurTechnologiesExpertiesTitle:'Our Technology Expertise',
        OurTechnologiesExpertiesPara:'Node.js development outsourcing is not the only professional service QArea’s experienced engineers can deliver. We have the skills and expertise in building high-quality software using the many other progressive technologies, programming languages, and tools.',
        OurTechnologiesExpertiesList:[
            {
                icon:<SiAdobeaftereffects/>,
                title:'Java',
            },
            {
             icon:<SiAdobephotoshop/>,
             title:'PHP',
         },
         {
             icon:<SiAdobephotoshop/>,
             title:'Golang',
         },
         {
             icon:<SiAdobephotoshop/>,
             title:'Node.Js',
         },
         {
            icon:<SiAdobeaftereffects/>,
            title:'Python',
        },
        {
         icon:<SiAdobephotoshop/>,
         title:'C#',
     },
     {
         icon:<SiAdobephotoshop/>,
         title:'.NET',
     },
     {
         icon:<SiAdobephotoshop/>,
         title:'c/c++',
     },
     {
        icon:<SiAdobephotoshop/>,
        title:'Electron',
    },
    {
        icon:<SiAdobephotoshop/>,
        title:'PostgreSQL',
    },
    {
        icon:<SiAdobephotoshop/>,
        title:'Flask',
    },
    {
        icon:<SiAdobephotoshop/>,
        title:'Django',
    },
    {
        icon:<SiAdobephotoshop/>,
        title:'Mongo',
    },
     ],
     DevelopmentGetStartedtitle:'How to Get Started' ,
     DevelopmentGetStarted:[
               {
                   icon:'',
                   title:'Reach out to us',
                   description:'Fill our contact form, tell us about your project, and we’ll be in touch within one business day.'
               },
               {
                icon:'',
                title:'Outline your goals',
                description:'Your personal manager will provide a quote based on your project requirements.'
            },
               {
                icon:'',
                title:'Meet your team',
                description:'We will handpick the best suitable candidates for your Node.js development project.',
               },
          
            {
                icon:'',
                title:'Get to work',
                description:'Now that your team is formed, let’s turn your ideas into a successful Node.js solution!'
            },
           ],
        DevelopmentservicesPara:'Pursue new business opportunities with Node.js development services. We will help you start fast and deploy with confidence.',
        BenefitsNodejsTitle:'Benefits of Node.js Development with Senwell Solutions',
        BenefitsNodejsList:[
           {
            Number:'01',
            title:'Trial Periods for New Employees',
            description:'We provide our clients with the opportunity to have a test run with the candidates before they finalize their choice. We want you to be confident we’ll get the job done on time and within budget.',
           },
           {
            Number:'02',
            title:'Transparent Code Monitoring',
            description:'When hiring from QArea, you get access to our proprietary tools that provide useful code quality metrics to help your project standardize the quality of code and maintain it on a high level.',
           },
           {
            Number:'03',
            title:'Equipment Rental Included',
            description:'You don’t pay any extra for our specialists’ workstations and the equipment they use. In addition, you get access to over 250 physical devices from smartphones to tablets to test your app.',
           },
           {
            Number:'04',
            title:'Flexible Workflows & Processes',
            description:'Our highly experienced specialists can not only get in sync with your team quickly and without effort, but help optimize the development processes to achieve maximum efficiency on the project.',
           },
           {
            Number:'05',
            title:'System Administration Included',
            description:'Don’t think about anything but your project’s success as we take care of all the administrative and IT support—help you set up efficient communication, integrate project management tools, etc.',
           },
           {
            Number:'06',
            title:'Fast Resource Replacement',
            description:'We are very scrupulous when it comes to picking the best candidates for our clients’ requirements. In case a discrepancy does happen, however, we provide a fitting replacement without delay.',
           },
        ],
        DevelopmntJounrneyTitle:'Lean back and enjoy your successful development journey!',
        DevelopmntJounrneyPara:'Build a scalable web app fast and within budget with expert-level Node.js development outsourcing. From a single engineer to an entire development team, we’ve got the talent you’re looking for.',
        DevelopmntJounrneyButtonText:'Get a Quote today',
        SuccessStoriesImg:' ',
        FullCycleSoftwareImg:'',
        FullCycleSoftwareTitle:'Full-cycle software development teams',
        FullCycleSoftwareDetails:'Project Manager',
        FullCycleSoftwareProjectManager:[
            {
                Text:'If you’d rather focus on the big picture, hire an experienced project manager to take care of your software development. QArea’s processes are appraised at CMMI-DEV Level 3. We excel at everything from planning and scheduling to progress tracking and workflow optimization.',
            }
        ],
        FullCycleSoftwareDetails:'Business Analyst',
        FullCycleSoftwareDetailsBusinesAnalyst:[
            {
                Text:'We have the right people to help point your project into the most profitable, future-proof direction. Through rigorous research and detailed documentation, our experienced business analysts will help you refine the project requirements and improve business processes.',
            }
        ],
        FullCycleSoftwareDetails:'UI/UX Designers',
        FullCycleSoftwareDetailsUIUXDesigners:[
            {
                Text:'In addition to equipping your software solution with a powerful backend, you need to make your frontend visually attractive, interactions intuitive, and user journeys as enjoyable as ever. If you need help designing an appealing UI and captivating UX, we have the right people for the job.',
            }
        ],
        FullCycleSoftwareDetails:'Developers',
        FullCycleSoftwareDetailsDevelopers:[
            {
                Text:'The engineers who turn thousands of lines of good code into great software, websites, and applications used by millions of people around the world.',
            }
        ],
        FullCycleSoftwareDetails:'DevOps Engineers',
        FullCycleSoftwareDetailsDevOpsEngineers:[
            {
                Text:'The ability to reduce the time needed to integrate changes while improving the quality is a great competitive edge to have in today’s software market. We employ best CI/CD practices to minimize the number of errors during integration and deployment to streamline your project.',
            }
        ],
        FullCycleSoftwareDetails:'Testing and QA Teams',
        FullCycleSoftwareDetailsTestingandQATeams:[
            {
                Text:'From meticulous manual testing to writing complex automated testing solutions, our bright QA engineers and scrupulous testing teams will make certain your software solution is free from any performance, stability, or functionality issues.',
            }
        ],
        FullCycleSoftwareButtonText:'Requists Specialists',
        ChooseUsTitel:'Why Choose Us',
        ChooseUs:[
            {
                icons:'',
                titel:'Start fast. Finish with confidence.',
                para:'Our goal is to help you launch quickly and make sure you’ll want to work with us again.',
            },
            {
                icons:'',
                titel:'100% Transparency',
                para:'Clear communication, flexible pricing, and full dedication to your success.',
            },
            {
                icons:'',
                titel:'Excellent Code Quality',
                para:'We check the quality of our code at every step of development to ensure best results.',
            },
            {
                icons:'',
                titel:'Cross-domain expertise',
                para:'Need services beyond Back-End Development? We will have you covered.',
            },
        ],
        FormDetailTitel:'Get a quote today!',
        FormDetailSubTitel:'Enter your project details.',
    },
    {
        id:6,
        Technologies:'back-end',
        name:'dot-net',
        breadcrums:'.Net Development Services',
        HeroParagraph:'We build robust applications for the web and mobile space utilizing the latest technologies including the .NET framework by Microsoft.',
        TargetExpertiesTitle:'We target our expertise at your business issues.',
        TargetExpertiesPara:'Throughout the years, we’ve managed to grow a team of high-class professionals who treat software development as a true calling, not just a career. We are picky about who we hire, that’s why signing a deal with QArea ensures you’ll get to work with some of the best .NET developers in Eastern Europe.',
        TargetExpertiesList:[
            {
                Numbers:'10+',
                Title:'Engineers',
                description:'Whether you hire one or more Node.js developers, we guarantee that you will be working with Middle and Senior level experts only.'
            },
            {
             Numbers:'20+',
             Title:' Projects',
             description:'Our portfolio is a solid demonstration of how we turn the needs of our clients into digital solutions.'
         },
         {
             Numbers:'15+',
             Title:'Years of Experience',
             description:'Having spent over a decade on the IT market, we understand every nuance of software development.'
         }   
        ],
        TechStackTitle:'Tech Stack',
        TechStackPara:'.NET development is only one of the many domains and technologies we’re skilled in. With every project we work on, our focus is the value it will add to our client and the industry in general. This explains our yearning for the cleanest code and seamless performance',
        TechStackList:[
            {
                icon:<SiAdobeaftereffects/>,
                title:'Java',
            },
            {
             icon:<SiAdobephotoshop/>,
             title:'PHP',
         },
         {
             icon:<SiAdobephotoshop/>,
             title:'Golang',
         },
         {
             icon:<SiAdobephotoshop/>,
             title:'Node.Js',
         },
         {
            icon:<SiAdobeaftereffects/>,
            title:'Python',
        },
        {
         icon:<SiAdobephotoshop/>,
         title:'C#',
     },
     {
         icon:<SiAdobephotoshop/>,
         title:'.NET',
     },
     {
         icon:<SiAdobephotoshop/>,
         title:'c/c++',
     },
     {
        icon:<SiAdobephotoshop/>,
        title:'Electron',
    },
    {
        icon:<SiAdobephotoshop/>,
        title:'PostgreSQL',
    },
    {
        icon:<SiAdobephotoshop/>,
        title:'Flask',
    },
    {
        icon:<SiAdobephotoshop/>,
        title:'Django',
    },
    {
        icon:<SiAdobephotoshop/>,
        title:'Mongo',
    },
     ],
     DevelopmentGetStartedtitle:'How to Get Started' ,
     DevelopmentGetStarted:[
               {
                   icon:'',
                   title:'Get to know us',
                   description:'Fill in a quick form so we can reach out to you and discuss your software development needs.'
               },
               {
                icon:'',
                title:'Set an objective',
                description:'A manager assigned to your project will help you define long-term goals for your software.'
            },
            {
                icon:'',
                title:'Form a team',
                description:'We’ll gather the most suitable .NET developers to work full-time on your project.'
            },
            {
                icon:'',
                title:'Start working',
                description:'After you’ve met and approved the team, the development process is all set for the new beginning!',
               },
           ],
        DevelopmentSoluctionPara:'You describe it ― we develop it! Hire .NET developers and we will turn your ideas into a capable software solution.',
        BenefitsNodejsTitle:'Benefits of .NET Development with Senwell Solutions',
        BenefitsNodejsList:[
           {
            Number:'01',
            title:'Microsoft certification',
            description:'Senwell Solutions is a Microsoft certified partner, meaning all of our .NET projects get technical support directly from MS.',
           },
           {
            Number:'02',
            title:'Business transparency',
            description:'You get limitless access to the results of our work on your project since day one.',
           },
           {
            Number:'03',
            title:'Flexible working process',
            description:'Arranging our technical partnership, we will fully adjust our operations to suit your routine and goals.',
           },
           {
            Number:'04',
            title:'Quality over everything',
            description:'Being quality-obsessed, we test apps in situations that most developers do not anticipate to happen.',
           },
           {
            Number:'05',
            title:'Full-cycle coverage',
            description:'You won’t bother about system administration, equipment, and human resources management ― we got it all.',
           },
           {
            Number:'06',
            title:'Lifetime support & updates',
            description:'Our work does not end with coding only; we’ll continue making sure your product is up-to-date and works as required.',
           },
        ],
        NETFrameworkTitle:'More Features, Same Smooth Performance ― with More Features, Same Smooth Performance ― with .NET Framework',
        NETFrameworkPara:'Our .NET developers do not blindly focus on a single approach. They look into all the possible options and choose the one that would fit your future software solution the best. Click below to get an estimation of your project.',
        NETFrameworkButtonText:'Estimate a Project',
        SuccessStoriesImg:' ',
        FullCycleSoftwareImg:'',
        FullCycleSoftwareTitle:'Full-cycle software development teams',
        FullCycleSoftwareDetails:'Project Manager',
        FullCycleSoftwareProjectManager:[
            {
                Text:'If you’d rather focus on the big picture, hire an experienced project manager to take care of your software development. QArea’s processes are appraised at CMMI-DEV Level 3. We excel at everything from planning and scheduling to progress tracking and workflow optimization.',
            }
        ],
        FullCycleSoftwareDetails:'Business Analyst',
        FullCycleSoftwareDetailsBusinesAnalyst:[
            {
                Text:'We have the right people to help point your project into the most profitable, future-proof direction. Through rigorous research and detailed documentation, our experienced business analysts will help you refine the project requirements and improve business processes.',
            }
        ],
        FullCycleSoftwareDetails:'UI/UX Designers',
        FullCycleSoftwareDetailsUIUXDesigners:[
            {
                Text:'In addition to equipping your software solution with a powerful backend, you need to make your frontend visually attractive, interactions intuitive, and user journeys as enjoyable as ever. If you need help designing an appealing UI and captivating UX, we have the right people for the job.',
            }
        ],
        FullCycleSoftwareDetails:'Developers',
        FullCycleSoftwareDetailsDevelopers:[
            {
                Text:'The engineers who turn thousands of lines of good code into great software, websites, and applications used by millions of people around the world.',
            }
        ],
        FullCycleSoftwareDetails:'DevOps Engineers',
        FullCycleSoftwareDetailsDevOpsEngineers:[
            {
                Text:'The ability to reduce the time needed to integrate changes while improving the quality is a great competitive edge to have in today’s software market. We employ best CI/CD practices to minimize the number of errors during integration and deployment to streamline your project.',
            }
        ],
        FullCycleSoftwareDetails:'Testing and QA Teams',
        FullCycleSoftwareDetailsTestingandQATeams:[
            {
                Text:'From meticulous manual testing to writing complex automated testing solutions, our bright QA engineers and scrupulous testing teams will make certain your software solution is free from any performance, stability, or functionality issues.',
            }
        ],
        FullCycleSoftwareButtonText:'Requists Specialists',
        ChooseUsTitel:'Why People Choose Us',
        ChooseUs:[
            {
                icons:'',
                titel:'Quick start',
                para:'We keep our processes bureaucracy-free, so it usually doesn’t take more than a few days to start the collaboration.',
            },
            {
                icons:'',
                titel:'Fair deal',
                para:'All our operations are 100% transparent and it’s only you who decides how deeply you want to be involved in the development.',
            },
            {
                icons:'',
                titel:'Flawless code',
                para:'We love software testing just as much as we love coding, so keep your expectations high when it comes to QA services from us.',
            },
            {
                icons:'',
                titel:'Industry experts',
                para:'If your project evolves into something more technically complex over time, no worries: so will your QArea dedicated team.',
            },
        ],
        FormDetailTitel:'Get a quote today!',
        FormDetailSubTitel:'Enter your project details.',
    },

    {
        id:7,
        Technologies:'Mobile',
        breadcrums:' Mobile App Developers',
        HeroParagraph:'Work with our skilled React Native engineers to build robust mobile applications using one of the most popular mobile development frameworks.',
        PassionatePeopleTitle:'Passionate People.Powerful Solutions.',
        PassionatePeoplePara:'Augment your project with deep technological expertise, customer-focused mindset, and innovation! We have a roster of immensely talented, experienced mobile application developers — great team players ready to fill in the technological gaps on your project team. Just give us your project specifications and we will handpick our best mobile application developers to match your competence requirements and budget.        ',
        PassionatePeopleList:[
            {
                Numbers:'20+',
                Title:'Extensive experience',
                description:'Years of reliable mobile application development service with a proven track record of success stories.'
            },
            {
             Numbers:'250+',
             Title:' Accomplished professionals ',
             description :'Qualified mobile application engineers with strong programming skills and deep expertise in various domains.'
         },
         {
             Numbers:'500+',
             Title:'Trusted partnerships',
             description:'Hundreds of companies around the world entrusted us with building and maintaining their apps.'
         }   
        ],
        OurTechnologiesExpertiesTitle:'Our Technology Expertise',
        OurTechnologiesExpertiesPara:'Our mobile application developers excel at React Native, Swift, Kotlin and many other robust programming languages, proven technologies, and frameworks. Whether you’re looking for a native or cross-platform application, a simple solution or a complex enterprise suite — our designers and engineers will have you covered.',
        OurTechnologiesExpertiesList:[
            {
                icon:<SiAdobeaftereffects/>,
                title:'Ios',
            },
            {
             icon:<SiAdobephotoshop/>,
             title:'Andried',
         },
         {
             icon:<SiAdobephotoshop/>,
             title:'React-Native',
         },
         {
             icon:<SiAdobephotoshop/>,
             title:'Obj-C',
         },
         {
            icon:<SiAdobeaftereffects/>,
            title:'Swift',
        },
        {
         icon:<SiAdobephotoshop/>,
         title:'Ionic',
     },
     {
         icon:<SiAdobephotoshop/>,
         title:'Cordova',
     },
     {
         icon:<SiAdobephotoshop/>,
         title:'Kotlin',
     },
     ],
     DevelopmentGetStartedtitle:'How to Get Started' ,
     DevelopmentGetStarted:[
               {
                   icon:'',
                   title:'Reach out to us',
                   description:'Fill out the contact form on our website providing basic information on what you need .'
               },
               {
                icon:'',
                title:'Outline your goals',
                description:'Now that we’ve connected and discussed the request, your personal manager will gather.'
            },
               {
                icon:'',
                title:'Meet your team',
                description:'We analyze your request and provide you with a list of handpicked candidates best.',
               },
          
            {
                icon:'',
                title:'Get to work',
                description:'Now that you’ve decided on your options for collaboration, the required specialists, their time.'
            },
           ],
        DevelopmentservicesPara:'Hire mobile application developers with niche programming skills, industry-specific expertise, and strict code quality standards',
        BenefitsTitle:'Benefits of Mobile App Development with Senwell Solutions',
        BenefitsList:[
           {
            Number:'01',
            title:'Free trial periods for new employees',
            description:'We provide our clients with the opportunity to have a test run with the candidates before they finalize their choice—for you to be confident we’ll get the job done on time and within budget.',
           },
           {
            Number:'02',
            title:'Transparent monitoring of code quality',
            description:'When hiring from QArea, you get access to our proprietary tools that provide useful code quality metrics to help your project standardize the quality of code and maintain it on a high level.',
           },
           {
            Number:'03',
            title:'Equipment Rental Included',
            description:'You don’t pay any extra for our specialists’ workstations and the equipment they use. In addition, you get access to over 250 physical devices from smartphones to tablets to test your app.',
           },
           {
            Number:'04',
            title:'System Administration Included',
            description:'Don’t think about anything but your project’s success as we take care of all the administrative and IT support—help you set up efficient communication, integrate project management tools, etc.',
           },
           {
            Number:'05',
            title:'Tailoring QArea and Company processes when required',
            description:'Our highly experienced specialists can not only get in sync with your team quickly and without effort, but help optimize the development processes to achieve maximum efficiency on the project.',
           },
           {
            Number:'06',
            title:'Instant replacement of undesirable resources',
            description:'We are very scrupulous when it comes to picking the best candidates for our clients’ requirements. In case a discrepancy does happen, however, we provide a fitting replacement without delay.',
           },
        ],
        MobileApplicationTitle:'Stand out from the crowd',
        MobileApplicationPara:'Ensure visibility and positive reception of your mobile solution by hiring mobile application developers from Senwell — a trusted tech partner of multiple Fortune 500 companies.',
        MobileApplicationButtonText:'Get a Quote today',
        SuccessStoriesImg:' ',
        FullCycleSoftwareImg:'',
        FullCycleSoftwareTitle:'Full-cycle software development teams',
        FullCycleSoftwareDetails:'Project Manager',
        FullCycleSoftwareProjectManager:[
            {
                Text:'If you’d rather focus on the big picture, hire an experienced project manager to take care of your software development. QArea’s processes are appraised at CMMI-DEV Level 3. We excel at everything from planning and scheduling to progress tracking and workflow optimization.',
            }
        ],
        FullCycleSoftwareDetails:'Business Analyst',
        FullCycleSoftwareDetailsBusinesAnalyst:[
            {
                Text:'We have the right people to help point your project into the most profitable, future-proof direction. Through rigorous research and detailed documentation, our experienced business analysts will help you refine the project requirements and improve business processes.',
            }
        ],
        FullCycleSoftwareDetails:'UI/UX Designers',
        FullCycleSoftwareDetailsUIUXDesigners:[
            {
                Text:'In addition to equipping your software solution with a powerful backend, you need to make your frontend visually attractive, interactions intuitive, and user journeys as enjoyable as ever. If you need help designing an appealing UI and captivating UX, we have the right people for the job.',
            }
        ],
        FullCycleSoftwareDetails:'Developers',
        FullCycleSoftwareDetailsDevelopers:[
            {
                Text:'The engineers who turn thousands of lines of good code into great software, websites, and applications used by millions of people around the world.',
            }
        ],
        FullCycleSoftwareDetails:'DevOps Engineers',
        FullCycleSoftwareDetailsDevOpsEngineers:[
            {
                Text:'The ability to reduce the time needed to integrate changes while improving the quality is a great competitive edge to have in today’s software market. We employ best CI/CD practices to minimize the number of errors during integration and deployment to streamline your project.',
            }
        ],
        FullCycleSoftwareDetails:'Testing and QA Teams',
        FullCycleSoftwareDetailsTestingandQATeams:[
            {
                Text:'From meticulous manual testing to writing complex automated testing solutions, our bright QA engineers and scrupulous testing teams will make certain your software solution is free from any performance, stability, or functionality issues.',
            }
        ],
        FullCycleSoftwareButtonText:'Requists Specialists',
        WhySenwellTitel:'Why Senwell Solutions',
        WhySenwell:[
            {
                icons:'',
                titel:'Start fast. Finish with confidence..',
                para:'Our goal is to help you launch quickly and make sure you’ll want to work with us again.',
            },
            {
                icons:'',
                titel:'100% Transparency',
                para:'Clear communication, flexible pricing, and full dedication to your success.',
            },
            {
                icons:'',
                titel:'Cross-domain expertise',
                para:'Senwell portfolio holds various projects belonging to the most diverse industries, from healthcare to automotive, finance, and eCommerce.',
            },
            {
                icons:'',
                titel:'Excellent Code Quality',
                para:'We check the quality of our code at every step of development to ensure best results.',
            },
        ],
        FormDetailTitel:'Write to us.',
        FormDetailSubTitel:'Tell us about your project.',
    },
    {
        id:8,
        Technologies:'Mobile',
        name:'React Native',
        breadcrums:' React Native Development Services',
        HeroParagraph:'Work with our skilled React Native engineers to build robust mobile applications using one of the most popular mobile development frameworks.',
        FastStartTitle:'Fast Start.',
        FastStartPara:'React Native is the ideal choice for companies that need a reliable mobile counterpart for their web-centered business. It will ensure that your application is fast, your UI renders quickly, and content is delivered to users without a hitch. Our React Native developers use the framework to its full potential, finding the single best way to implement the features your business needs to succeed.',
        FastStartList:[
            {
                Numbers:'10+',
                Title:'React Native Developers',
                description:'We guarantee that you will work with only the most talented Middle and Senior-level React Native engineers.'
            },
            {
             Numbers:'15+',
             Title:' Projects Delivered ',
             description :'Our Agile approach and perfected workflows allow us to combine cost-efficiency with quick delivery.'
         },
         {
             Numbers:'8',
             Title:'Years of Experience',
             description:'Since its release, React Native has been the framework of choice for many of our most demanding projects.'
         }   
        ],
        OurTechnologiesExpertiesTitle:'Our Technology Expertise',
        OurTechnologiesExpertiesPara:'Since its release, React Native has been the framework of choice for many of our most demanding projects.',
        OurTechnologiesExpertiesList:[
            {
                icon:<SiAdobeaftereffects/>,
                title:'Ios',
            },
            {
             icon:<SiAdobephotoshop/>,
             title:'Andried',
         },
         {
             icon:<SiAdobephotoshop/>,
             title:'React-Native',
         },
         {
             icon:<SiAdobephotoshop/>,
             title:'Obj-C',
         },
         {
            icon:<SiAdobeaftereffects/>,
            title:'Swift',
        },
        {
         icon:<SiAdobephotoshop/>,
         title:'Ionic',
     },
     {
         icon:<SiAdobephotoshop/>,
         title:'Cordova',
     },
     {
         icon:<SiAdobephotoshop/>,
         title:'Kotlin',
     },
     
     ],
     DevelopmentGetStartedtitle:'How to Get Started' ,
     DevelopmentGetStarted:[
               {
                   icon:'',
                   title:'Reach out to us',
                   description:'Fill out the contact form on our website providing basic information on what you need .'
               },
               {
                icon:'',
                title:'Outline your goals',
                description:'Now that we’ve connected and discussed the request, your personal manager will gather.'
            },
               {
                icon:'',
                title:'Meet your team',
                description:'We analyze your request and provide you with a list of handpicked candidates best.',
               },
          
            {
                icon:'',
                title:'Get to work',
                description:'Now that you’ve decided on your options for collaboration, the required specialists, their time.'
            },
           ],
        DevelopmentservicesPara:'Ready to conquer the digital frontier? Build a powerful native or cross-platform mobile app with experienced React Native engineers!',
        BenefitsReactNativeTitle:'Building React Native mobile apps with Senwell Solutions',
        BenefitsReact:[
           {
            Number:'01',
            title:'Free trial periods for new employees',
            description:'We provide our clients with the opportunity to have a test run with the candidates before they finalize their choice—for you to be confident we’ll get the job done on time and within budget.',
           },
           {
            Number:'02',
            title:'Transparent monitoring of code quality',
            description:'When hiring from QArea, you get access to our proprietary tools that provide useful code quality metrics to help your project standardize the quality of code and maintain it on a high level.',
           },
           {
            Number:'03',
            title:'Equipment Rental Included',
            description:'You don’t pay any extra for our specialists’ workstations and the equipment they use. In addition, you get access to over 250 physical devices from smartphones to tablets to test your app.',
           },
           {
            Number:'04',
            title:'System Administration Included',
            description:'Don’t think about anything but your project’s success as we take care of all the administrative and IT support—help you set up efficient communication, integrate project management tools, etc.',
           },
           {
            Number:'05',
            title:'Tailoring QArea and Company processes when required',
            description:'Our highly experienced specialists can not only get in sync with your team quickly and without effort, but help optimize the development processes to achieve maximum efficiency on the project.',
           },
           {
            Number:'06',
            title:'Instant replacement of undesirable resources',
            description:'We are very scrupulous when it comes to picking the best candidates for our clients’ requirements. In case a discrepancy does happen, however, we provide a fitting replacement without delay.',
           },
        ],
        GetAQuoteTitle:'Have an idea? Let’s get to work!',
        GetAQuotePara:'Whether you need a single engineer or an entire team, our React Native developers are ready to prove themselves to you. Run a pilot project to make certain QArea is exactly what you’re looking for!',
        GetAQuoteButtonText:' Get A Quote',
        SuccessStoriesImg:' ',
        FullCycleSoftwareImg:'',
        FullCycleSoftwareTitle:'Full-cycle software development teams',
        FullCycleSoftwareDetails:'Project Manager',
        FullCycleSoftwareProjectManager:[
            {
                Text:'If you’d rather focus on the big picture, hire an experienced project manager to take care of your software development. QArea’s processes are appraised at CMMI-DEV Level 3. We excel at everything from planning and scheduling to progress tracking and workflow optimization.',
            }
        ],
        FullCycleSoftwareDetails:'Business Analyst',
        FullCycleSoftwareDetailsBusinesAnalyst:[
            {
                Text:'We have the right people to help point your project into the most profitable, future-proof direction. Through rigorous research and detailed documentation, our experienced business analysts will help you refine the project requirements and improve business processes.',
            }
        ],
        FullCycleSoftwareDetails:'UI/UX Designers',
        FullCycleSoftwareDetailsUIUXDesigners:[
            {
                Text:'In addition to equipping your software solution with a powerful backend, you need to make your frontend visually attractive, interactions intuitive, and user journeys as enjoyable as ever. If you need help designing an appealing UI and captivating UX, we have the right people for the job.',
            }
        ],
        FullCycleSoftwareDetails:'Developers',
        FullCycleSoftwareDetailsDevelopers:[
            {
                Text:'The engineers who turn thousands of lines of good code into great software, websites, and applications used by millions of people around the world.',
            }
        ],
        FullCycleSoftwareDetails:'DevOps Engineers',
        FullCycleSoftwareDetailsDevOpsEngineers:[
            {
                Text:'The ability to reduce the time needed to integrate changes while improving the quality is a great competitive edge to have in today’s software market. We employ best CI/CD practices to minimize the number of errors during integration and deployment to streamline your project.',
            }
        ],
        FullCycleSoftwareDetails:'Testing and QA Teams',
        FullCycleSoftwareDetailsTestingandQATeams:[
            {
                Text:'From meticulous manual testing to writing complex automated testing solutions, our bright QA engineers and scrupulous testing teams will make certain your software solution is free from any performance, stability, or functionality issues.',
            }
        ],
        FullCycleSoftwareButtonText:'Requists Specialists',
        SenwellSolutionTitel:'Why Senwell Solutions',
        SenwellSolutions:[
            {
                icons:'',
                titel:'Start fast. Finish with confidence.',
                para:'Our goal is to help you launch quickly and make sure you’ll want to work with us again.',
            },
            {
                icons:'',
                titel:'100% Transparency',
                para:'Clear communication, flexible pricing, and full dedication to your success.',
            },
            {
                icons:'',
                titel:'Excellent Code Quality',
                para:'We check the quality of our code at every step of development to ensure best results.',
            },
            {
                icons:'',
                titel:'Cross-domain expertise',
                para:'Need services beyond Back-End Development? We will have you covered.',
            },
        ],
        FormDetailTitel:'Get a quote today!',
        FormDetailSubTitel:'Enter your project details.',
    },    
   ]
   export default Technologies