import { CmmiImage } from '../images/images'
import { Union } from '../images/images'
import { LogoImage } from '../images/images'
import { WebDevelopmentBanner } from '../images/images'
import { impresNewClientFlowImg } from '../images/images'
import { SiAdobephotoshop } from "react-icons/si";
import { GetInTouchBanner } from '../images/images'
import { huffpostImg } from '../images/images'
import { Dashlane } from '../images/images'
import { Code_Better } from '../images/images'
import { Distractify } from '../images/images'
import {TestingBanner} from '../images/images'
import '../App.css'

const Services = [
  {
    name: 'web-development',
    HeroBanner: [{
      Page: 'Web Development',
      title: 'Expert ',
      breadcrums: 'services',
      Link:'/services',
      spanText: 'Web Development',
      title2: 'Services',
      para: 'Help your business reach new digital heights with a powerful web solution built and optimized by your friendly neighborhood web development outsourcing company.',
      button: 'Hire Now',
      img: WebDevelopmentBanner,
      image1: CmmiImage,
      image2: Union,
      image3: LogoImage,
    }],
    GetInTouchTitle: 'Ready to start on your development or testing project? We are!',
    Button: 'GetInTouch',
    formTitle: "Get a quote today!",
    formSubtitle: 'Enter your project details.',
    ImpressYourClientTitle: 'Impress new Clients',
    ImpressYourClientPara: 'Bring your business online with reliable web development services. Extend your reach with engaging web portals, close deals with robust marketplaces, and serve your customers with custom-tailored applications. Show customers your best side with the looks and experiences they will enjoy from landing to checkout. ',
    ImpressYourClientImage: impresNewClientFlowImg,
    ImpressYourClientPoints: [
      {
        li: 'corporate websites'
      },
      {
        li: 'eCommerse Platforms'
      },
      {
        li: 'Sass & cloud Solutions'
      },
      {
        li: 'media Portals'
      },
    ],
    DevelopmentSolutionsTitle: 'Ideal Web Development Solutions',
    DevelopmentSolutionsList: [
      {
        ariaControls: "panel1a-content",
        id: "panel1a-header",
        Number: '01',
        AccordianSummary: 'Websites & Web Apps',
        AccordianDetails: " Build your online image with engaging looks, intuitive layouts, and compelling user experience.",
        List1: 'corporate websites',
        List2: 'Landing Pages',
        List3: ' Progressive Web Apps',
        List4: 'Single-page Applications',
        List5: 'Microservices',
      },
      {
        ariaControls: "panel2a-content",
        id: "panel2a-header",
        Number: '02',
        AccordianSummary: 'Websites & Web Apps',
        AccordianDetails: " Build your online image with engaging looks, intuitive layouts, and compelling user experience.",
        List1: 'corporate websites',
        List2: 'Landing Pages',
        List3: ' Progressive Web Apps',
        List4: 'Single-page Applications',
        List5: 'Microservices',
      },
      {
        ariaControls: "panel3a-content",
        id: "panel3a-header",
        Number: '03',
        AccordianSummary: 'Websites & Web Apps',
        AccordianDetails: " Build your online image with engaging looks, intuitive layouts, and compelling user experience.",
        List1: 'corporate websites',
        List2: 'Landing Pages',
        List3: ' Progressive Web Apps',
        List4: 'Single-page Applications',
        List5: 'Microservices',
      },
      {
        ariaControls: "panel2a-content",
        id: "panel2a-header",
        Number: '02',
        AccordianSummary: 'Websites & Web Apps',
        AccordianDetails: " Build your online image with engaging looks, intuitive layouts, and compelling user experience.",
        List1: 'corporate websites',
        List2: 'Landing Pages',
        List3: ' Progressive Web Apps',
        List4: 'Single-page Applications',
        List5: 'Microservices',
      },
      {
        ariaControls: "panel2a-content",
        id: "panel2a-header",
        Number: '02',
        AccordianSummary: 'Websites & Web Apps',
        AccordianDetails: " Build your online image with engaging looks, intuitive layouts, and compelling user experience.",
        List1: 'corporate websites',
        List2: 'Landing Pages',
        List3: ' Progressive Web Apps',
        List4: 'Single-page Applications',
        List5: 'Microservices',
      },
    ],
    TechnologiesExpertiesTitle: 'Tech Stack',
    TechnologiesExpertiesPara: 'Our expertise does not end with Angular development outsourcing. Our skills and experience cover almost every programming language, framework, and library, both proven by years and recently introduced by industry leaders like Google or Microsoft.',
    TechnologiesExperties: [
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop1',
      },
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop2',
      },
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop3',
      },
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop4',
      },
    ],
    GetInTouchSecondbanner: [{
      GetInTouchTitle: 'Set your project on the course to continuous improvement',
      Button: "Lets's talk",
      image: '',
      para: 'Hire an experienced DevOps services company to help ensure utmost functional and non-functional quality of your software solutions.',
    }],

    Testimonials: [
      {
        label:
          "“The team did excellent work and I was very happy with everyone we added to the project via QArea. Together we built a custom video CMS in Django and native apps for iOS and Android powered by json feeds from this CMS.”",
        img: "",
        name: "Theo Burry",
        post: "Former CTO at NowThis Media, Inc.",
      },
      {
        label:
          "“QArea has shown to have very competent resources, and have delivered the quality that our team was expecting. Concerns arose over time (that’s expected) but you have always been very proactive in resolving them. ”",
        img: "",
        name: "Peter Dunham,",
        post: "Co-founder, Mr. Baffo.",
      },
      {
        label:
          "“QArea has consistently delivered quality product for us and have been very accommodating when we were on tight schedules to complete our projects on time. We look forward to our continued development efforts with their team. ”",
        img: "",
        name: "Jon Sugihara,",
        post: "President & Co-Founder at Perx.",
      },
      {
        label:
          "“QArea has played a critical role in the development of HuffingtonPost.com. They have been able to become a part of the core team very quickly and develop amazing features that perform under the highest performance and demand requirements possible.”",
        img: "",
        name: "Paul Berry,",
        post: "CTO at the HuffPost.",
      },
      {
        label:
          "“The team were extremely responsive, with a quick turnaround, excellent client communications and have the flexibility to adapt to new requests. Responsive design can present a number of challenges but QArea were up to it and found the right solutions to meet our needs.”",
        img: "",
        name: " Julie Gilbert-Binns,",
        post: "3rd Wave Communications.",
      },
      {
        label:
          "“QArea was able to assist us with the design and development of a brand new site that our customers love. Because we have a CMS now, we can manage many aspects of the e-commerce site ourselves. Their team is responsive and professional and we always felt like our new site was in good hands. ”",
        img: "",
        name: "Katherine VanHenley,",
        post: "Third & Wall.",
      },
    ],
    Forms: [
      {
        formTitle: "Let's talk",
        formSubtitle: 'Tell us about your project. Let’s get to work!'
      }
    ]

  },

  {
    name: 'application-development',
    HeroBanner: [{
      Page: 'Application Development',
      title: 'Mobile ',
      breadcrums: 'services',
      Link:'/services',
      spanText: 'Application Development',
      title2: 'Experts',
      para: 'Solid tech expertise, nearly two decades of experience, and cross-domain background make QArea the best choice for custom mobile app development services.',
      button: 'Hire Now',
      img: WebDevelopmentBanner,
      image1: CmmiImage,
      image2: Union,
      image3: LogoImage,
    }],
    ImpressYourClientTitle: 'Dazzle Your Users',
    ImpressYourClientPara: 'Client-facing software can either save or drown your business: a good mobile app will generate leads and drive sales, while a low-quality solution can scare people away. Our mobile application development services deliver top-notch apps that help companies thrive.',
    ImpressYourClientImage: impresNewClientFlowImg,
    ImpressYourClientPoints: [
      {
        li: 'Native & Cross-Platform Apps'
      },
      {
        li: 'Mobile UI/UX Design'
      },
      {
        li: 'AR Applications'
      },
      {
        li: 'APIs and Cloud solutions'
      },
      {
        li: 'mCommerce apps'
      },
    ],
    DevelopmentSolutionsTitle: 'Superb Mobile App Development Services',
    DevelopmentSolutionsList: [
      {
        ariaControls: "panel1a-content",
        id: "panel1a-header",
        Number: '01',
        AccordianSummary: 'Native Application Development',
        AccordianDetails: "No app performs as smoothly as a native mobile application built specifically for iOS or Android. ",
        List1: 'iOS Applications',
        List2: 'Android Applications',

      },
      {
        ariaControls: "panel2a-content",
        id: "panel2a-header",
        Number: '02',
        AccordianSummary: 'Cross-Platform & Hybrid Applications',
        AccordianDetails: "Hybrid mobile development allows using one app on different platforms, from smartphones to PCs. ",
        List1: 'React Native development',
        List2: 'Xamarin development',
        List3: 'Flutter development',
      },
      {
        ariaControls: "panel3a-content",
        id: "panel3a-header",
        Number: '',
        AccordianSummary: 'Application Porting',
        AccordianDetails: " Already enjoying the success of your app on a platform? Port it to other platforms to expand your audience!",
        List1: 'Web App to Mobile App porting',
        List2: 'iOS to Android porting',
        List3: 'Android to iOS porting',
      },
      {
        ariaControls: "panel4a-content",
        id: "panel4a-header",
        Number: '',
        AccordianSummary: 'Mobile SDK Development',
        AccordianDetails: "SDK includes things like libraries, documents, and integration tools for custom app development.",
        List1: 'IoT integrations',
        List2: 'Integration of Geo, Accelerometer, and other sensors',
        List3: ' Bluetooth API',
        List4: 'Use of custom sensors',
        List5: 'AR/VR implementation',
      },
    ],
    GetInTouch: [{
      GetInTouchTitle: 'Need a mobile application development partner to turn your idea into a notable mobile solution?',
      Button: 'GetInTouch',
    }],
    TechnologiesExpertiesTitle: 'Technology We Mastered',
    TechnologiesExpertiesPara: 'When deciding on programming languages and tools for another mobile app development project, we always focus on future code quality, product value for the market, and budget frames to stay in. That’s why mobile solutions we release always correspond to industry standards as well as reflect every penny invested in development.',
    TechnologiesExperties: [
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: '',
      },
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: '',
      },
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: '',
      },
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: '',
      },
    ],

    ProjectPortfollio: [
      {
        title: 'HuffPost',
        image: huffpostImg,
        para: 'High traffic is both the main goal and challenges for the news websites.we helped HuffPost build a site and app that are increadibly convenient to use and capable of sustaining the heavy usage load.Having optimized the front-end and back-end of HuffPost,our client can be sure that their message delivery system can send 150,000 messages per second'
      },
      {
        title: 'Dashlane',
        image: Dashlane,
        para: '  Security is important for individuals as well as businesses. Our QA engineers helped Dashlane ensure that their password manager and digital wallet will remain fully functional on new versions of OS, browsers, and devices. Now our client knows that their solution works perfectly under all circumstances.'
      },
      {
        title: 'Code Better',
        image: Code_Better,
        para: ' We developed an effective web application that helps developers to write semantically correct code and form useful coding habits with better practices, superior tools, and proven methodologies.The application provides thorough data analysis and real-time statistics as well as features such as sorting errors by priority. The app is compatible with all popular desktop and mobile devices.'
      },
      {
        title: 'Distractify',
        image: Distractify,
        para: '  New businesses must strike while the iron is hot. Chasing after a fast time-to-market can make your business vulnerable to performance risks. We helped Distractify perform a fast but extremely thorough Quality Assurance process before they hit “publish” on their first viral story.'
      },
    ],
    GetInTouchSecondbanner: [{
      GetInTouchTitle: 'We’re ready to start. Are you?',
      Button: 'Start a project',
      image: GetInTouchBanner,
      para: 'Tell us what kind of mobile application you’ve got in mind. From researching the app’s market niche to designing, coding, and then testing it — the rest is the job of our mobile application development services.',
    }],
    Testimonials: [
      {
        label:
          "“The team did excellent work and I was very happy with everyone we added to the project via QArea. Together we built a custom video CMS in Django and native apps for iOS and Android powered by json feeds from this CMS.”",
        img: "",
        name: "Theo Burry",
        post: "Former CTO at NowThis Media, Inc.",
      },
      {
        label:
          "“QArea has shown to have very competent resources, and have delivered the quality that our team was expecting. Concerns arose over time (that’s expected) but you have always been very proactive in resolving them. ”",
        img: "",
        name: "Peter Dunham,",
        post: "Co-founder, Mr. Baffo.",
      },
      {
        label:
          "“QArea has consistently delivered quality product for us and have been very accommodating when we were on tight schedules to complete our projects on time. We look forward to our continued development efforts with their team. ”",
        img: "",
        name: "Jon Sugihara,",
        post: "President & Co-Founder at Perx.",
      },
      {
        label:
          "“QArea has played a critical role in the development of HuffingtonPost.com. They have been able to become a part of the core team very quickly and develop amazing features that perform under the highest performance and demand requirements possible.”",
        img: "",
        name: "Paul Berry,",
        post: "CTO at the HuffPost.",
      },
      {
        label:
          "“The team were extremely responsive, with a quick turnaround, excellent client communications and have the flexibility to adapt to new requests. Responsive design can present a number of challenges but QArea were up to it and found the right solutions to meet our needs.”",
        img: "",
        name: " Julie Gilbert-Binns,",
        post: "3rd Wave Communications.",
      },
      {
        label:
          "“QArea was able to assist us with the design and development of a brand new site that our customers love. Because we have a CMS now, we can manage many aspects of the e-commerce site ourselves. Their team is responsive and professional and we always felt like our new site was in good hands. ”",
        img: "",
        name: "Katherine VanHenley,",
        post: "Third & Wall.",
      },
    ],
    Forms: [
      {
        formTitle: "Get a quote today!",
        formSubtitle: 'Enter your project details.'
      }
    ]
  } ,
   {
    name: 'it-consulting',
    HeroBanner: [{
      Page: 'IT consulting',
      title: 'IT ',
      breadcrums: 'Services',
      Link:'/services',
      spanText: 'Consulting ',
      title2: 'Services',
      para: 'Whether you want to learn how to effectively launch a software project or find ways to improve your internal processes, request a free IT consultation from our experts.',
      button: 'Request free call',
      img: WebDevelopmentBanner,
      image1: CmmiImage,
      image2: Union,
      image3: LogoImage,
    }],
   
    ImpressYourClientTitle: 'Start Development Quickly',
    ImpressYourClientPara: 'Don’t let the lack of technical background stop you from starting a disruptive business. Our IT consulting services can help you determine your idea’s feasibility, create a development roadmap, and assist you in creating a prototype or MVP that will help you validate your ideas.',
    ImpressYourClientImage: impresNewClientFlowImg,
    ImpressYourClientPoints: [
      {
        li: 'CTO as a Service'
      },
      {
        li: 'Market research'
      },
      {
        li: 'Creating development roadmaps'
      },
      {
        li: 'Guided MVP creation'
      },
    ],
    DevelopmentSolutionsTitle: 'IT Consulting Services  ',
    DevelopmentSolutionsList: [
      {
        ariaControls: "panel1a-content",
        id: "panel1a-header",
        Number: '01',
        AccordianSummary: 'SDLC Workflow Optimization',
        AccordianDetails: " Make sure every step of your development lifecycle is geared to minimizing costs and increasing output. We can help your team run like a fine-tuned Swiss watch.",
        List1: 'Development & QA process audit',
        List2: 'Creating thorough documentation',
        List3: 'Improving onboarding practices',
        List4: 'Agile & Lean methodology coaching',
      
      },
      {
        ariaControls: "panel2a-content",
        id: "panel2a-header",
        Number: '02',
        AccordianSummary: 'Project Planning',
        AccordianDetails: " Create a roadmap for turning your idea into a working product used by millions. Our product development consultants can help you create a development roadmap, choose key features for your MVP, and find a team to write your first lines of code.",
        List1: 'Market & Competitor research',
        List2: 'Prototype and MVP planning',
        List3: 'Creating development roadmaps',
        List4: 'Assistance with forming a team and hiring',
      },
      {
        ariaControls: "panel3a-content",
        id: "panel3a-header",
        Number: '03',
        AccordianSummary: 'Adherence to Industry Best Practices',
        AccordianDetails: " Make sure your team is adhering to industry best practices in regards to processes, information security, and quality standards.",
  
       List1: 'Assistance with CMMI-DEV maturity',
        List2: 'Information security audit ISO:27001',
        List3: 'Assistance with achieving industry-specific standards ',
      },
    {
        ariaControls: "panel2a-content",
        id: "panel2a-header",
        Number: '02',
        AccordianSummary: 'CTO as a Service',
        AccordianDetails: " Completely outsource the technical supervision of your project to a qualified CTO with years of experience. This professional will help you choose the best frameworks, languages, and architecture for your project.",
        List2: 'ut development plans into action',
        List3: ' Ensure thorough technical supervision of your project',
        List4: 'Leverage decades of hands-on experience',
        List5: 'Make well-informed technical decisions',
      },
    ],
    TechnologiesExpertiesTitle: 'Tech Stack',
    TechnologiesExpertiesPara: 'Our expertise does not end with Angular development outsourcing. Our skills and experience cover almost every programming language, framework, and library, both proven by years and recently introduced by industry leaders like Google or Microsoft.',
    TechnologiesExperties: [
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop1',
      },
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop2',
      },
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop3',
      },
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop4',
      },
    ],
    GetInTouchSecondbanner: [{
      GetInTouchTitle: 'Set your project on the course to continuous improvement',
      Button: "Lets's talk",
      image: '',
      para: 'Hire an experienced DevOps services company to help ensure utmost functional and non-functional quality of your software solutions.',
    }],

    Testimonials: [
      {
        label:
          "“The team did excellent work and I was very happy with everyone we added to the project via QArea. Together we built a custom video CMS in Django and native apps for iOS and Android powered by json feeds from this CMS.”",
        img: "",
        name: "Theo Burry",
        post: "Former CTO at NowThis Media, Inc.",
      },
      {
        label:
          "“QArea has shown to have very competent resources, and have delivered the quality that our team was expecting. Concerns arose over time (that’s expected) but you have always been very proactive in resolving them. ”",
        img: "",
        name: "Peter Dunham,",
        post: "Co-founder, Mr. Baffo.",
      },
      {
        label:
          "“QArea has consistently delivered quality product for us and have been very accommodating when we were on tight schedules to complete our projects on time. We look forward to our continued development efforts with their team. ”",
        img: "",
        name: "Jon Sugihara,",
        post: "President & Co-Founder at Perx.",
      },
      {
        label:
          "“QArea has played a critical role in the development of HuffingtonPost.com. They have been able to become a part of the core team very quickly and develop amazing features that perform under the highest performance and demand requirements possible.”",
        img: "",
        name: "Paul Berry,",
        post: "CTO at the HuffPost.",
      },
      {
        label:
          "“The team were extremely responsive, with a quick turnaround, excellent client communications and have the flexibility to adapt to new requests. Responsive design can present a number of challenges but QArea were up to it and found the right solutions to meet our needs.”",
        img: "",
        name: " Julie Gilbert-Binns,",
        post: "3rd Wave Communications.",
      },
      {
        label:
          "“QArea was able to assist us with the design and development of a brand new site that our customers love. Because we have a CMS now, we can manage many aspects of the e-commerce site ourselves. Their team is responsive and professional and we always felt like our new site was in good hands. ”",
        img: "",
        name: "Katherine VanHenley,",
        post: "Third & Wall.",
      },
    ],
    Forms: [
      {
        formTitle: "Let's talk",
        formSubtitle: 'Tell us about your project. Let’s get to work!'
      }
    ]

  },
  {
    name: 'mvp-development',
    HeroBanner: [{
      Page: 'IT consulting',
      title: 'IT ',
      breadcrums: 'Services',
      Link:'/services',
      spanText: 'Consulting ',
      title2: 'Services',
      para: 'Whether you want to learn how to effectively launch a software project or find ways to improve your internal processes, request a free IT consultation from our experts.',
      button: 'Request free call',
      img: WebDevelopmentBanner,
      image1: CmmiImage,
      image2: Union,
      image3: LogoImage,
    }],
   
    ImpressYourClientTitle: 'Start Development Quickly',
    ImpressYourClientPara: 'Don’t let the lack of technical background stop you from starting a disruptive business. Our IT consulting services can help you determine your idea’s feasibility, create a development roadmap, and assist you in creating a prototype or MVP that will help you validate your ideas.',
    ImpressYourClientImage: impresNewClientFlowImg,
    ImpressYourClientPoints: [
      {
        li: 'CTO as a Service'
      },
      {
        li: 'Market research'
      },
      {
        li: 'Creating development roadmaps'
      },
      {
        li: 'Guided MVP creation'
      },
    ],
    DevelopmentSolutionsTitle: 'IT Consulting Services  ',
    DevelopmentSolutionsList: [
      {
        ariaControls: "panel1a-content",
        id: "panel1a-header",
        Number: '01',
        AccordianSummary: 'SDLC Workflow Optimization',
        AccordianDetails: " Make sure every step of your development lifecycle is geared to minimizing costs and increasing output. We can help your team run like a fine-tuned Swiss watch.",
        List1: 'Development & QA process audit',
        List2: 'Creating thorough documentation',
        List3: 'Improving onboarding practices',
        List4: 'Agile & Lean methodology coaching',
      
      },
      {
        ariaControls: "panel2a-content",
        id: "panel2a-header",
        Number: '02',
        AccordianSummary: 'Project Planning',
        AccordianDetails: " Create a roadmap for turning your idea into a working product used by millions. Our product development consultants can help you create a development roadmap, choose key features for your MVP, and find a team to write your first lines of code.",
        List1: 'Market & Competitor research',
        List2: 'Prototype and MVP planning',
        List3: 'Creating development roadmaps',
        List4: 'Assistance with forming a team and hiring',
      },
      {
        ariaControls: "panel3a-content",
        id: "panel3a-header",
        Number: '03',
        AccordianSummary: 'Adherence to Industry Best Practices',
        AccordianDetails: " Make sure your team is adhering to industry best practices in regards to processes, information security, and quality standards.",
  
       List1: 'Assistance with CMMI-DEV maturity',
        List2: 'Information security audit ISO:27001',
        List3: 'Assistance with achieving industry-specific standards ',
      },
    {
        ariaControls: "panel2a-content",
        id: "panel2a-header",
        Number: '02',
        AccordianSummary: 'CTO as a Service',
        AccordianDetails: " Completely outsource the technical supervision of your project to a qualified CTO with years of experience. This professional will help you choose the best frameworks, languages, and architecture for your project.",
        List2: 'ut development plans into action',
        List3: ' Ensure thorough technical supervision of your project',
        List4: 'Leverage decades of hands-on experience',
        List5: 'Make well-informed technical decisions',
      },
    ],
    TechnologiesExpertiesTitle: 'Tech Stack',
    TechnologiesExpertiesPara: 'Our expertise does not end with Angular development outsourcing. Our skills and experience cover almost every programming language, framework, and library, both proven by years and recently introduced by industry leaders like Google or Microsoft.',
    TechnologiesExperties: [
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop1',
      },
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop2',
      },
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop3',
      },
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop4',
      },
    ],
    GetInTouchSecondbanner: [{
      GetInTouchTitle: 'Set your project on the course to continuous improvement',
      Button: "Lets's talk",
      image: '',
      para: 'Hire an experienced DevOps services company to help ensure utmost functional and non-functional quality of your software solutions.',
    }],

    Testimonials: [
      {
        label:
          "“The team did excellent work and I was very happy with everyone we added to the project via QArea. Together we built a custom video CMS in Django and native apps for iOS and Android powered by json feeds from this CMS.”",
        img: "",
        name: "Theo Burry",
        post: "Former CTO at NowThis Media, Inc.",
      },
      {
        label:
          "“QArea has shown to have very competent resources, and have delivered the quality that our team was expecting. Concerns arose over time (that’s expected) but you have always been very proactive in resolving them. ”",
        img: "",
        name: "Peter Dunham,",
        post: "Co-founder, Mr. Baffo.",
      },
      {
        label:
          "“QArea has consistently delivered quality product for us and have been very accommodating when we were on tight schedules to complete our projects on time. We look forward to our continued development efforts with their team. ”",
        img: "",
        name: "Jon Sugihara,",
        post: "President & Co-Founder at Perx.",
      },
      {
        label:
          "“QArea has played a critical role in the development of HuffingtonPost.com. They have been able to become a part of the core team very quickly and develop amazing features that perform under the highest performance and demand requirements possible.”",
        img: "",
        name: "Paul Berry,",
        post: "CTO at the HuffPost.",
      },
      {
        label:
          "“The team were extremely responsive, with a quick turnaround, excellent client communications and have the flexibility to adapt to new requests. Responsive design can present a number of challenges but QArea were up to it and found the right solutions to meet our needs.”",
        img: "",
        name: " Julie Gilbert-Binns,",
        post: "3rd Wave Communications.",
      },
      {
        label:
          "“QArea was able to assist us with the design and development of a brand new site that our customers love. Because we have a CMS now, we can manage many aspects of the e-commerce site ourselves. Their team is responsive and professional and we always felt like our new site was in good hands. ”",
        img: "",
        name: "Katherine VanHenley,",
        post: "Third & Wall.",
      },
    ],
    Forms: [
      {
        formTitle: "Let's talk",
        formSubtitle: 'Tell us about your project. Let’s get to work!'
      }
    ]

  },
]
export { Services }

const DevopsData = [
  {

    HeroBanner: [{
      Page: 'DevOps',
      title: 'DevOps  ',
      breadcrums: 'services',
      Link:'/services',
      spanText: 'Services For SMEs and ',
      title2: 'Enterprises',
      para: 'Plan your projects thoroughly and improve your ability to deliver applications, scale them, and build your solutions on reliable infrastructure.',
      button: 'Get In Touch',
      img: WebDevelopmentBanner,
      image1: CmmiImage,
      image2: Union,
      image3: LogoImage,
    }],

    ImpressYourClientTitle: 'Serve Your Users',
    ImpressYourClientPara: 'Good DevOps allow teams to release more frequently and maintain a balance between quality and innovation. Give your end-users the pleasure of regular updates and your stakeholders the satisfaction of a faster time-to-market. Work with us to improve your:',
    ImpressYourClientImage: impresNewClientFlowImg,
    ImpressYourClientPoints: [
      {
        li: 'Deployment & Delivery process'
      },
      {
        li: 'Scalability using cloud services'
      },
      {
        li: 'Global availability of your product'
      },
      {
        li: 'Release frequency'
      },
    ],
    DevelopmentSolutionsTitle: 'Ideal Web Development Solutions',
    DevelopmentSolutionsList: [
      {
        ariaControls: "panel1a-content",
        id: "panel1a-header",
        Number: '01',
        AccordianSummary: 'Cloud Adoption',
        AccordianDetails: " Reduce your IT costs, improve the performance of your software, and ensure the scalability and reliability of your project.",
        List1: 'Cloud Migration',
        List2: 'DDos Detection and Prevention',
        List3: 'AWS Infrastructure',
        List4: 'Regular Backups',
      },
      {
        ariaControls: "panel2a-content",
        id: "panel2a-header",
        Number: '02',
        AccordianSummary: 'Team Improvements',
        AccordianDetails: "Go beyond improvements to your product and increase the efficiency of your in-house development and testing teams.",
        List1: 'Streamline deployment and delivery',
        List2: 'Improve employee engagement',
        List3: ' Create thorough technical documentation',
      },
      {
        ariaControls: "panel3a-content",
        id: "panel3a-header",
        Number: '03',
        AccordianSummary: 'Delivery Pipeline (CI/CD)',
        AccordianDetails: " Help your team implement CI/CD best practices to reduce post-release debugging, improve issue resolution time, and achieve a faster TTM.",
        List1: 'End-to-End CI/CD Automation with Azure',
        List2: 'Streamlined Deployment',
        List3: ' Thorough quality control',
        List4: 'Reduced lead time',

      },
      {
        ariaControls: "panel2a-content",
        id: "panel2a-header",
        Number: '02',
        AccordianSummary: 'Thoughtful Software Architecture',
        AccordianDetails: " Go beyond code quality and software testing by ensuring that your software architecture meets the long-term goals of your project. ",
        List1: 'Planning microservices-based architecture',
        List2: 'Breaking down monolith architecture',
        List3: 'Implementation of service-based architecture',
        List4: 'Project architecture planning services',
      },
      {
        ariaControls: "panel2a-content",
        id: "panel2a-header",
        Number: '02',
        AccordianSummary: 'Websites & Web Apps',
        AccordianDetails: " Build your online image with engaging looks, intuitive layouts, and compelling user experience.",
        List1: 'corporate websites',
        List2: 'Landing Pages',
        List3: ' Progressive Web Apps',
        List4: 'Single-page Applications',
        List5: 'Microservices',
      },
    ],
    GetInTouch: [{

      GetInTouchTitle: 'Prepare your next project for continuous success with our DevOps outsourcing!',
      Button: 'Schedule a Call',
    }],

    TechnologiesExpertiesTitle: 'Our Technology Expertise',
    TechnologiesExpertiesPara: 'DevOps services is just one of the numerous domains we’re experienced in. QArea has a roster of more than 280 dedicated engineers with extensive knowledge of niche technologies, programming languages, frameworks, and libraries. We go beyond writing good code, focusing on an end result that will help your business achieve its objectives.',
    TechnologiesExperties: [
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop1',
      },
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop2',
      },
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop3',
      },
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop4',
      },
    ],
    GetInTouchSecondbanner: [{
      GetInTouchTitle: 'Want a free consultation on your project?',
      Button: 'Get In Touch',
      para: 'We can help you choose the best-suited engagement model for your project so you’ve reached your business goals the soonest and without overpaying for it.',
    }],
    Testimonials: [
      {
        label:
          "“The team did excellent work and I was very happy with everyone we added to the project via QArea. Together we built a custom video CMS in Django and native apps for iOS and Android powered by json feeds from this CMS.”",
        img: "",
        name: "Theo Burry",
        post: "Former CTO at NowThis Media, Inc.",
      },
      {
        label:
          "“QArea has shown to have very competent resources, and have delivered the quality that our team was expecting. Concerns arose over time (that’s expected) but you have always been very proactive in resolving them. ”",
        img: "",
        name: "Peter Dunham,",
        post: "Co-founder, Mr. Baffo.",
      },
      {
        label:
          "“QArea has consistently delivered quality product for us and have been very accommodating when we were on tight schedules to complete our projects on time. We look forward to our continued development efforts with their team. ”",
        img: "",
        name: "Jon Sugihara,",
        post: "President & Co-Founder at Perx.",
      },
      {
        label:
          "“QArea has played a critical role in the development of HuffingtonPost.com. They have been able to become a part of the core team very quickly and develop amazing features that perform under the highest performance and demand requirements possible.”",
        img: "",
        name: "Paul Berry,",
        post: "CTO at the HuffPost.",
      },
      {
        label:
          "“The team were extremely responsive, with a quick turnaround, excellent client communications and have the flexibility to adapt to new requests. Responsive design can present a number of challenges but QArea were up to it and found the right solutions to meet our needs.”",
        img: "",
        name: " Julie Gilbert-Binns,",
        post: "3rd Wave Communications.",
      },
      {
        label:
          "“QArea was able to assist us with the design and development of a brand new site that our customers love. Because we have a CMS now, we can manage many aspects of the e-commerce site ourselves. Their team is responsive and professional and we always felt like our new site was in good hands. ”",
        img: "",
        name: "Katherine VanHenley,",
        post: "Third & Wall.",
      },
    ],
    ProjectPortfollio: [
      {
        title: 'HuffPost',
        image: huffpostImg,
        para: 'High traffic is both the main goal and challenges for the news websites.we helped HuffPost build a site and app that are increadibly convenient to use and capable of sustaining the heavy usage load.Having optimized the front-end and back-end of HuffPost,our client can be sure that their message delivery system can send 150,000 messages per second'
      },
      {
        title: 'Dashlane',
        image: Dashlane,
        para: '  Security is important for individuals as well as businesses. Our QA engineers helped Dashlane ensure that their password manager and digital wallet will remain fully functional on new versions of OS, browsers, and devices. Now our client knows that their solution works perfectly under all circumstances.'
      },
      {
        title: 'Code Better',
        image: Code_Better,
        para: ' We developed an effective web application that helps developers to write semantically correct code and form useful coding habits with better practices, superior tools, and proven methodologies.The application provides thorough data analysis and real-time statistics as well as features such as sorting errors by priority. The app is compatible with all popular desktop and mobile devices.'
      },
      {
        title: 'Distractify',
        image: Distractify,
        para: '  New businesses must strike while the iron is hot. Chasing after a fast time-to-market can make your business vulnerable to performance risks. We helped Distractify perform a fast but extremely thorough Quality Assurance process before they hit “publish” on their first viral story.'
      },
    ],
    Forms: [
      {
        formTitle: "Let's talk",
        formSubtitle: 'Tell us about your project. Let’s get to work!'
      }
    ]

  },

]
export { DevopsData }


const TestingData = [
  {
    name:'Testing & QA',
    HeroBanner: [{
      Page: 'Testing & QA',
      Breadcrumbs:'Testing & QA',
      Link:'/services',
      section: 'Services',
      spanText: 'Software QA',
      title2: ' Services',
      para: 'Improve your SDLC by implementing thoroughly planned and polished quality assurance workflows on your project. Get the most out of your testing and QA.',
      button: "Let's talk",
      img: TestingBanner,
      image1: CmmiImage,
      image2: Union,
      image3: LogoImage,
    }
    ],
    GetInTouch : [{
      GetInTouchTitle:'Download a sample of our thorough testing reports.',
       Button:'Download',
  }],
  ProjectPortfollio : [
    {
        title:'HuffPost',
        image:huffpostImg,
        para:'High traffic is both the main goal and challenges for the news websites.we helped HuffPost build a site and app that are increadibly convenient to use and capable of sustaining the heavy usage load.Having optimized the front-end and back-end of HuffPost,our client can be sure that their message delivery system can send 150,000 messages per second'
    },
    {
        title:'Dashlane',
        image:Dashlane,
        para:'  Security is important for individuals as well as businesses. Our QA engineers helped Dashlane ensure that their password manager and digital wallet will remain fully functional on new versions of OS, browsers, and devices. Now our client knows that their solution works perfectly under all circumstances.'
    },
    {
        title:'Code Better',
        image:Code_Better,
        para:' We developed an effective web application that helps developers to write semantically correct code and form useful coding habits with better practices, superior tools, and proven methodologies.The application provides thorough data analysis and real-time statistics as well as features such as sorting errors by priority. The app is compatible with all popular desktop and mobile devices.'
    },
    {
        title:'Distractify',
        image:Distractify,
        para:'  New businesses must strike while the iron is hot. Chasing after a fast time-to-market can make your business vulnerable to performance risks. We helped Distractify perform a fast but extremely thorough Quality Assurance process before they hit “publish” on their first viral story.'
    },
],
TechnologiesExpertiesTitle: 'Quality Assurance Technologies',
TechnologiesExpertiesPara: 'Our software QA services involve a wide range of robust tools and latest technologies to effectively report bugs and maintain your software product at an exceptional level of quality. The manual and automated testing we perform ensures speedy delivery and broad test coverage on your project.',
TechnologiesExperties: [
    {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'JavaScript',
    },
    {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Angular',
    },
    {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'React',
    },
    {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'TypeScript',
    },
    {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Vue.Js',
    },
],
Testimonials : [
  {
    label:
      "“The team did excellent work and I was very happy with everyone we added to the project via QArea. Together we built a custom video CMS in Django and native apps for iOS and Android powered by json feeds from this CMS.”",
    img: "",
    name: "Theo Burry",
    post: "Former CTO at NowThis Media, Inc.",
  },
  {
    label:
      "“QArea has shown to have very competent resources, and have delivered the quality that our team was expecting. Concerns arose over time (that’s expected) but you have always been very proactive in resolving them. ”",
    img: "",
    name: "Peter Dunham,",
    post: "Co-founder, Mr. Baffo.",
  },
  {
    label:
      "“QArea has consistently delivered quality product for us and have been very accommodating when we were on tight schedules to complete our projects on time. We look forward to our continued development efforts with their team. ”",
    img: "",
    name: "Jon Sugihara,",
    post: "President & Co-Founder at Perx.",
  },
  {
    label:
      "“QArea has played a critical role in the development of HuffingtonPost.com. They have been able to become a part of the core team very quickly and develop amazing features that perform under the highest performance and demand requirements possible.”",
    img: "",
    name: "Paul Berry,",
    post: "CTO at the HuffPost.",
  },
  {
    label:
      "“The team were extremely responsive, with a quick turnaround, excellent client communications and have the flexibility to adapt to new requests. Responsive design can present a number of challenges but QArea were up to it and found the right solutions to meet our needs.”",
    img: "",
    name: " Julie Gilbert-Binns,",
    post: "3rd Wave Communications.",
  },
  {
    label:
      "“QArea was able to assist us with the design and development of a brand new site that our customers love. Because we have a CMS now, we can manage many aspects of the e-commerce site ourselves. Their team is responsive and professional and we always felt like our new site was in good hands. ”",
    img: "",
    name: "Katherine VanHenley,",
    post: "Third & Wall.",
  },
],
Forms:[
  {
  formTitle:"Write to us.",
  formSubtitle:'Tell us about your project.'
  }
]
  }
]
export {TestingData}
const ProductDevelopmentData =[
  {

    HeroBanner: [{
      Page: 'DevOps',
      title: 'Product Development  ',
      breadcrums: 'services',
      Link:'/services',
      spanText: 'Solutions We Deliver ',
      title2: 'Enterprises',
      para: 'Maximize the value delivered to the market with a software product built and refined by our internal product development team.',
      button: 'Get In Touch',
      img: WebDevelopmentBanner,
      image1: CmmiImage,
      image2: Union,
      image3: LogoImage,
    }],

    
    DevelopmentSolutionsTitle: 'Ideal Web Development Solutions',
    DevelopmentSolutionsList: [
      {
        ariaControls: "panel1a-content",
        id: "panel1a-header",
        Number: '01',
        AccordianSummary: 'New Product Development',
        AccordianDetails: "From verifying your ideas to building full-fledged solutions, we will help drive your project to success.",
        List1: 'Proof of concept',
        List2: 'Prototype development',
        List3: 'MVP development',
        List4: 'SaaS development',
      },
      {
        ariaControls: "panel2a-content",
        id: "panel2a-header",
        Number: '02',
        AccordianSummary: 'Perfect Product/Market Fit',
        AccordianDetails: "From solid product vision to best-fitting business model, we refine ideas into profitable, scalable products.",
        List1: 'Data-driven analytics',
        List2: 'Code quality assessment',
        List3: 'Market research',
        List4:'Considered UI/UX'
      },
      {
        ariaControls: "panel3a-content",
        id: "panel3a-header",
        Number: '03',
        AccordianSummary: 'Integrations & Microservices',
        AccordianDetails: " Upgrade your existing software with self-sustaining microservices and seamlessly integrated modules.",
        List1: 'New feature implementation',
        List2: 'Microservices-based architecture',
        List3: 'Third-party API integration',
        List4: 'Continuous maintenance and support',
      },
      {
        ariaControls: "panel4a-content",
        id: "panel4a-header",
        Number: '04',
        AccordianSummary: 'B2B & B2C Software',
        AccordianDetails: " Extensive experience and industry knowledge in building strong-suited web, mobile, and desktop solutions. ",
        List1: 'Social networks & dating platforms',
        List2: 'Project management & business tools',
        List3: 'Code quality & source code security tools',
        List4: 'PDF generators',
      },
    ],
    GetInTouch: [{

      GetInTouchTitle: 'Looking for a product development team to refine your ideas into strong-suited software?',
      Button: 'Schedule a Call',
    }],

    TechnologiesExpertiesTitle: 'Our Technology Expertise',
    TechnologiesExpertiesPara: '',
    TechnologiesExperties: [
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop1',
      },
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop2',
      },
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop3',
      },
      {
        icon: <SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title: 'Photoshop4',
      },
    ],
    GetInTouchSecondbanner: [{
      GetInTouchTitle: 'Want a free consultation on your project?',
      Button: 'Get In Touch',
      para: 'We can help you choose the best-suited engagement model for your project so you’ve reached your business goals the soonest and without overpaying for it.',
    }],
    Testimonials: [
      {
        label:
          "“The team did excellent work and I was very happy with everyone we added to the project via QArea. Together we built a custom video CMS in Django and native apps for iOS and Android powered by json feeds from this CMS.”",
        img: "",
        name: "Theo Burry",
        post: "Former CTO at NowThis Media, Inc.",
      },
      {
        label:
          "“QArea has shown to have very competent resources, and have delivered the quality that our team was expecting. Concerns arose over time (that’s expected) but you have always been very proactive in resolving them. ”",
        img: "",
        name: "Peter Dunham,",
        post: "Co-founder, Mr. Baffo.",
      },
      {
        label:
          "“QArea has consistently delivered quality product for us and have been very accommodating when we were on tight schedules to complete our projects on time. We look forward to our continued development efforts with their team. ”",
        img: "",
        name: "Jon Sugihara,",
        post: "President & Co-Founder at Perx.",
      },
      {
        label:
          "“QArea has played a critical role in the development of HuffingtonPost.com. They have been able to become a part of the core team very quickly and develop amazing features that perform under the highest performance and demand requirements possible.”",
        img: "",
        name: "Paul Berry,",
        post: "CTO at the HuffPost.",
      },
      {
        label:
          "“The team were extremely responsive, with a quick turnaround, excellent client communications and have the flexibility to adapt to new requests. Responsive design can present a number of challenges but QArea were up to it and found the right solutions to meet our needs.”",
        img: "",
        name: " Julie Gilbert-Binns,",
        post: "3rd Wave Communications.",
      },
      {
        label:
          "“QArea was able to assist us with the design and development of a brand new site that our customers love. Because we have a CMS now, we can manage many aspects of the e-commerce site ourselves. Their team is responsive and professional and we always felt like our new site was in good hands. ”",
        img: "",
        name: "Katherine VanHenley,",
        post: "Third & Wall.",
      },
    ],
    GetInTouchSecondbanner : [{
      GetInTouchTitle:'Follow best Angular development standards',
       Button:'Estimate a project',
      image:"",
       para:'The client-facing side of an app determines its success. After all, if it doesn’t look and work well, who’s going to use it? Our Angular development services pair developers with designers to create the most inviting, intuitive, and memorable user interfaces for your users to enjoy.',
  }],
    ProjectPortfollio: [
      {
        title: 'HuffPost',
        image: huffpostImg,
        para: 'High traffic is both the main goal and challenges for the news websites.we helped HuffPost build a site and app that are increadibly convenient to use and capable of sustaining the heavy usage load.Having optimized the front-end and back-end of HuffPost,our client can be sure that their message delivery system can send 150,000 messages per second'
      },
      {
        title: 'Dashlane',
        image: Dashlane,
        para: '  Security is important for individuals as well as businesses. Our QA engineers helped Dashlane ensure that their password manager and digital wallet will remain fully functional on new versions of OS, browsers, and devices. Now our client knows that their solution works perfectly under all circumstances.'
      },
      {
        title: 'Code Better',
        image: Code_Better,
        para: ' We developed an effective web application that helps developers to write semantically correct code and form useful coding habits with better practices, superior tools, and proven methodologies.The application provides thorough data analysis and real-time statistics as well as features such as sorting errors by priority. The app is compatible with all popular desktop and mobile devices.'
      },
      {
        title: 'Distractify',
        image: Distractify,
        para: '  New businesses must strike while the iron is hot. Chasing after a fast time-to-market can make your business vulnerable to performance risks. We helped Distractify perform a fast but extremely thorough Quality Assurance process before they hit “publish” on their first viral story.'
      },
    ],
    Forms: [
      {
        formTitle: "Let's talk",
        formSubtitle: 'Tell us about your project. Let’s get to work!'
      }
    ]

  },
]
export{ProductDevelopmentData}