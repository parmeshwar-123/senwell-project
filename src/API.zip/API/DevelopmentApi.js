import { DesignHeroBanner } from '../images/images'
import { SiAdobephotoshop } from "react-icons/si";
import { SiAdobeillustrator } from "react-icons/si";
import { SiAdobeaftereffects } from "react-icons/si";
import {huffpostImg} from'../images/images'
import {Dashlane} from'../images/images'
import {Code_Better} from'../images/images'
import {Distractify} from'../images/images'
import FlashOnIcon from '@material-ui/icons/FlashOn';
import SearchIcon from '@material-ui/icons/Search';
import StarIcon from '@material-ui/icons/Star';
import LocationOnIcon from '@material-ui/icons/LocationOn';
const DevelopmentData = [
    {
        HeroBanner: [{
            Page: ' Custom software development',
            section: 'Services',
            title: 'Custom Software ',
            Breadcrumbs: 'services',
            Link:'/services',
            spanText: 'Development   ',
            title2: 'Services',
            para: 'Our custom software development team can help you create disruptive solutions, breathtaking web apps, and business software that will help your enterprise meet key objectives. ',
            button: 'Get in Touch',
            img: DesignHeroBanner,
        },
        ],
        GetInTouch : [{
            GetInTouchImage:'',
            GetInTouchTitle:'Ready to start on your development or testing project? We are!',
             Button:'Get In Touch',
        }],
        Benefits:[{ 
            title:'Benefits of Angular',
            Benefitstitle: ' Development with Senwell',
            BenefitsofDevelopmentWithSenwell: [
                {
                    Number:'01',
                    title:'Trial Periods for New Employees',
                    description:'We provide our clients with the opportunity to have a test run with the candidates before they finalize their choice. We want you to be confident we’ll get the job done on time and within budget.',
                   },
                   {
                    Number:'02',
                    title:'Transparent Code Monitoring',
                    description:'When hiring from QArea, you get access to our proprietary tools that provide useful code quality metrics to help your project standardize the quality of code and maintain it on a high level.',
                   },
                   {
                    Number:'03',
                    title:'Equipment Rental Included',
                    description:'You don’t pay any extra for our specialists’ workstations and the equipment they use. In addition, you get access to over 250 physical devices from smartphones to tablets to test your app.',
                   },
                   {
                    Number:'04',
                    title:'Flexible Workflows & Processes',
                    description:'Our highly experienced specialists can not only get in sync with your team quickly and without effort, but help optimize the development processes to achieve maximum efficiency on the project.',
                   },
                   {
                    Number:'05',
                    title:'System Administration Included',
                    description:'Don’t think about anything but your project’s success as we take care of all the administrative and IT support—help you set up efficient communication, integrate project management tools, etc.',
                   },
                   {
                    Number:'06',
                    title:'Fast Resource Replacement',
                    description:'We are very scrupulous when it comes to picking the best candidates for our clients’ requirements. In case a discrepancy does happen, however, we provide a fitting replacement without delay.',
                   },
            ],
        }],
        TechnologiesExpertiesTitle:'Our Technology Expertise',
        TechnologiesExpertiesPara:'Node.js development outsourcing is not the only professional service QArea’s experienced engineers can deliver. We have the skills and expertise in building high-quality software using the many other progressive technologies, programming languages, and tools.',

        TechnologiesExperties:[
            {
                icon:<SiAdobeaftereffects className="icon" style={{i: '#4eb7ff'}}/>,
                title:'Java',
            },
         {
             icon:<SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
             title:'Node.Js',
         },
         {
            icon:<SiAdobeaftereffects className="icon" style={{i: '#4eb7ff'}}/>,
            title:'Python',
        },
        
      
     {
         icon:<SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
         title:'.NET',
     },
  
    {
        icon:<SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title:'PostgreSQL',
    },
    {
        icon:<SiAdobephotoshop className="icon" style={{i: '#4eb7ff'}}/>,
        title:'Mongo',
    },
        ],
        GetInTouch: [{
            GetInTouchTitle: 'Run a pilot project to ensure QArea’s React outsourcing expertise is exactly what your business needs.',
            Button: 'Get In Touch',
        }],

        ProjectPortfollio : [
            {
                title:'HuffPost',
                image:huffpostImg,
                para:'High traffic is both the main goal and challenges for the news websites.we helped HuffPost build a site and app that are increadibly convenient to use and capable of sustaining the heavy usage load.Having optimized the front-end and back-end of HuffPost,our client can be sure that their message delivery system can send 150,000 messages per second'
            },
            {
                title:'Dashlane',
                image:Dashlane,
                para:'  Security is important for individuals as well as businesses. Our QA engineers helped Dashlane ensure that their password manager and digital wallet will remain fully functional on new versions of OS, browsers, and devices. Now our client knows that their solution works perfectly under all circumstances.'
            },
            {
                title:'Code Better',
                image:Code_Better,
                para:' We developed an effective web application that helps developers to write semantically correct code and form useful coding habits with better practices, superior tools, and proven methodologies.The application provides thorough data analysis and real-time statistics as well as features such as sorting errors by priority. The app is compatible with all popular desktop and mobile devices.'
            },
            {
                title:'Distractify',
                image:Distractify,
                para:'  New businesses must strike while the iron is hot. Chasing after a fast time-to-market can make your business vulnerable to performance risks. We helped Distractify perform a fast but extremely thorough Quality Assurance process before they hit “publish” on their first viral story.'
            },
        ],
        whysenwell:[
           
            {
                icon:<FlashOnIcon style={{ color: '#3D8ED7', paddingBottom: '1rem',fontSize:'2.5rem'}}/>,
                title:'Start fast. Finish with confidence.',
                para:'We want you to find a team quickly and get straight to turning your vision into a reality.',
            },
            {
                icon:<SearchIcon  style={{ color: '#3D8ED7', paddingBottom: '1rem',fontSize:'2.5rem',}}/>,
                title:'100% Transparency',
                para:'Clear and consistent communication, flexible pricing, and full dedication to your success',
            },
            {
                icon:<StarIcon  style={{ color: '#3D8ED7', paddingBottom: '1rem',fontSize:'2.5rem',}}/>,
                title:'Excellent Code Quality',
                para:'Beyond QA, we ensure your code is clean and free of technical debt. ',
            },
            {
                icon:<LocationOnIcon  style={{ color: '#3D8ED7', paddingBottom: '1rem',fontSize:'2.5rem',}}/>,
                title:'Cross-domain expertise',
                para:'There’s no challenge we can’t handle with confidence and great aplomb.',
            },

        ],
    }
]
export {DevelopmentData}