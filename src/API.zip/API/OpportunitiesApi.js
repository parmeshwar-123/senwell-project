import {opportunities} from '../images/images'
const OpportunitiesData = [
    {
        HeroBanner: [{
            Page: 'Culture & Opportunities',
            title: 'Your ',
            Breadcrumbs:'Career',
            Link:'/careers/opportunity',
            spanText: 'Opportunity ',
            title2:'Area',
            para: 'Embark on a thrilling adventure with innovative technologies, challenging projects, and unlimited growth potential.',
            img: opportunities,
            section:'  careers'
        },
        ],
        Forms:[
            {
            formTitle:'Send us your CV!',
            
            }
        ]
    },
]
export {OpportunitiesData}